# -*- coding: utf-8 -*-
def classFactory(iface):
    from .main import GPKGEditor
    return GPKGEditor(iface)