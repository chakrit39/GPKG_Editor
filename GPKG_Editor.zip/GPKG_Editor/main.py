import requests
import zipfile
import io
import os
from qgis.PyQt.QtCore import Qt, QSettings
from qgis.PyQt.QtWidgets import (QAction, QFileDialog, QMessageBox, QDialog,
                                QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton,
                                QLabel, QListWidget, QAbstractItemView, QInputDialog, QFrame,
                                QProgressDialog, QApplication, QShortcut, QKeySequenceEdit,
                                QFormLayout, QScrollArea, QDialogButtonBox, QWidget)
from qgis.core import (QgsProject, QgsVectorLayer, QgsRasterLayer, QgsRectangle,
                       QgsGeometry, QgsPointXY, QgsFeatureRequest,
                       QgsSymbol, QgsSingleSymbolRenderer, QgsPalLayerSettings,
                       QgsTextFormat, QgsVectorLayerSimpleLabeling,
                       QgsSnappingConfig, QgsTolerance, QgsPointLocator, QgsWkbTypes, QgsFeature,
                       QgsCoordinateReferenceSystem)
from qgis.gui import (QgsMapToolIdentifyFeature, QgsMapTool,
                      QgsSnapIndicator,
                      QgsMapToolEmitPoint,
                      QgsRubberBand)
from qgis.PyQt.QtGui import QColor, QIcon, QKeySequence


# ค่าคงที่ tolerance (คูณกับ mapUnitsPerPixel → ระยะจริงบนแผนที่)
# รวมไว้ที่เดียวเพื่อปรับค่าทีเดียวมีผลทุกเครื่องมือ
CLICK_TOL_PX = 10   # รัศมีคลิกเลือกหมุด / snap จุดปิดแปลง
NODE_TOL_PX = 5     # รัศมีจับคู่ vertex ของ polygon กับตำแหน่งหมุด
DRAG_MIN_PX = 2     # ระยะขั้นต่ำที่ถือว่าเป็นการลากกรอบ (ไม่ใช่คลิกเดี่ยว)
SNAP_TOL_PX = 20    # tolerance ของระบบ snapping

# ประวัติการเปลี่ยนแปลง (ใหม่สุดอยู่บนสุด) — ใช้กับ popup "มีอะไรใหม่"
CHANGELOG = [
    ("1.1.0", [
        "กด Enter ในหน้าต่างปลั๊กอิน = สแกนและโหลดข้อมูลทันที",
        "เติม utmmap1-4 / utmscale / landno จากโครงสร้างโฟลเดอร์ให้อัตโนมัติทุกครั้งที่บันทึก",
        "รองรับโฉนดที่มีหลายก้อนแยกกัน: Shift+คลิกขวา = ปิดก้อนแล้ววาดก้อนถัดไป, คลิกขวา = จบแปลง",
        "บันทึกไม่สำเร็จจะไม่ทิ้งงานอีกแล้ว — งานยังอยู่ครบ กดบันทึกซ้ำได้ (กันงานหายเมื่อไฟล์บนแชร์ถูกล็อก)",
        "คลิกขวาเพื่อปิดรูปแปลงได้จริง (ตรงกับคำแนะนำบนหน้าจอ)",
        "ย้ายหมุดลื่นขึ้น + เส้นตัวอย่างแสดงครบทุกแปลงที่ใช้หมุดร่วมกัน",
        "จำโฟลเดอร์ล่าสุดให้อัตโนมัติ",
        "ตรวจไฟล์ GPKG ว่ามีเลเยอร์ครบก่อนเปิดเครื่องมือ + แก้ลากกรอบแนวดิ่งตอนลบหมุด + กันคีย์ลัดพังก่อนโหลดงาน",
    ]),
    ("1.0.9", [
        "เพิ่มคีย์ลัดตั้งค่าเองได้ (⌨ ตั้งค่าคีย์ลัด) + เช็คคีย์ชนกับ QGIS",
        "เพิ่ม popup สรุปสิ่งที่เปลี่ยนหลังอัปเดต",
        "ปรับ Undo ให้แม่นยำขึ้น — ไม่ย้อนผิดเลเยอร์อีกต่อไป",
        "ลบหมุดที่ทำให้แปลงเหลือ < 3 มุม จะถูกกันไว้ + เตือน (ไม่ลบหมุดทิ้งโดยที่ node ค้าง)",
    ]),
    ("1.0.8", [
        "เพิ่มปุ่ม 🧹 ลบรูปแปลงและหมุดทั้งหมด (Undo ได้)",
        "แก้บั๊กค้าง/แครชตอนโหลด Template และการเทียบเวอร์ชัน",
        "แถบดาวน์โหลดอัปเดตตอบสนอง + กดยกเลิกได้",
    ]),
    ("1.0.7", [
        "ตรวจงานค้างก่อนโหลดงานใหม่",
        "เพิ่มความเร็วเครื่องมือ ลบ/ย้าย/แทรกหมุด",
    ]),
]


class GPKGEditorDialog(QDialog):
    def __init__(self, parent=None):
        super(GPKGEditorDialog, self).__init__(parent)
        self.version = "1.1.0"
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.setWindowIcon(QIcon(icon_path))
        self.setWindowTitle(f"GPKG Editor {self.version}")
        self.setMinimumWidth(400)
        layout = QVBoxLayout(self)

        # --- โซนที่ 1: การสแกนและโหลดข้อมูล ---
        layout.addWidget(QLabel("<b>📁 โซนสแกนและโหลดข้อมูล</b>"))
        path_layout = QHBoxLayout()
        self.line_path = QLineEdit()
        # เติมโฟลเดอร์ล่าสุดที่โหลดสำเร็จให้อัตโนมัติ ไม่ต้อง browse ใหม่ทุกครั้ง
        self.line_path.setText(QSettings().value("GPKGEditor/lastFolder", "", str))
        self.btn_browse = QPushButton("เลือก Folder...")
        self.btn_browse.clicked.connect(self.browse_folder)
        path_layout.addWidget(self.line_path)
        path_layout.addWidget(self.btn_browse)
        layout.addLayout(path_layout)

        self.btn_load = QPushButton("🚀 สแกนและโหลดข้อมูล")
        self.btn_load.setStyleSheet("font-weight: bold; height: 35px; background-color: #e1f5fe;")
        # ปุ่ม default ของหน้าต่าง — กด Enter (เช่น หลังพิมพ์/วาง path) = โหลดข้อมูลทันที
        # ต้องปิด autoDefault ของปุ่ม Browse ไม่งั้น Enter ในช่อง path จะไปโดนปุ่มแรกแทน
        self.btn_load.setAutoDefault(True)
        self.btn_load.setDefault(True)
        self.btn_browse.setAutoDefault(False)
        layout.addWidget(self.btn_load)

        # เส้นแบ่งโซน
        line1 = QFrame()
        line1.setFrameShape(QFrame.HLine)
        line1.setFrameShadow(QFrame.Sunken)
        layout.addWidget(line1)
        layout.addSpacing(5)

        self.UTMMAP = QLabel("<i>ยังไม่ได้สแกนและโหลดข้อมูล</i>")
        self.UTMMAP.setStyleSheet("font-weight: bold; padding: 5px; background-color: #f0f4c3; ")
        info_font = self.UTMMAP.font()
        info_font.setPointSize(16)
        self.UTMMAP.setFont(info_font)
        self.UTMMAP.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.UTMMAP)

        # เส้นแบ่งโซน
        layout.addSpacing(5)
        line1_ = QFrame()
        line1_.setFrameShape(QFrame.HLine)
        line1_.setFrameShadow(QFrame.Sunken)
        layout.addWidget(line1_)
        layout.addSpacing(5)

        row_init_layout = QHBoxLayout()
        self.btn_create_init = QPushButton("🆕 สร้างรูปแปลงและหมุดใหม่")
        self.btn_create_init.setStyleSheet("font-weight: bold; height: 35px; ")
        self.btn_create_init.setEnabled(False)

        self.btn_delete_all = QPushButton("🧹 ลบรูปแปลงและหมุดทั้งหมด")
        self.btn_delete_all.setStyleSheet("font-weight: bold; height: 35px; background-color: #ffebee; color: #c62828;")
        self.btn_delete_all.setEnabled(False)

        row_init_layout.addWidget(self.btn_create_init)
        row_init_layout.addWidget(self.btn_delete_all)
        layout.addLayout(row_init_layout)

        layout.addSpacing(5)
        line1_1 = QFrame()
        line1_1.setFrameShape(QFrame.HLine)
        line1_1.setFrameShadow(QFrame.Sunken)
        layout.addWidget(line1_1)
        layout.addSpacing(5)

        # --- โซนที่ 2: เครื่องมือจัดการหมุด (จัดกลุ่มซ้าย-ขวา) ---
        layout.addWidget(QLabel("<b>🛠️ เครื่องมือจัดการหมุด</b>"))

        # บรรทัด: ย้ายหมุด (ซ้าย) | แทรกหมุด (ขวา)
        row1_layout = QHBoxLayout()
        self.btn_move_point = QPushButton("📍 ย้ายหมุด")
        self.btn_move_point.setStyleSheet("font-weight: bold; height: 35px; ")
        self.btn_move_point.setEnabled(False)

        self.btn_insert_point = QPushButton("➕ แทรกหมุด")
        self.btn_insert_point.setStyleSheet("font-weight: bold; height: 35px; ")
        self.btn_insert_point.setEnabled(False)

        row1_layout.addWidget(self.btn_move_point)
        row1_layout.addWidget(self.btn_insert_point)
        layout.addLayout(row1_layout)

        # บรรทัด: แก้ไขชื่อหมุด (ซ้าย) | ลบหมุด (ขวา)
        row2_layout = QHBoxLayout()
        self.btn_edit_point = QPushButton("✏️ แก้ไขชื่อหมุด")
        self.btn_edit_point.setStyleSheet("font-weight: bold; height: 35px;")
        self.btn_edit_point.setEnabled(False)

        self.btn_delete_point = QPushButton("🗑️ ลบหมุด")
        self.btn_delete_point.setStyleSheet("font-weight: bold; height: 35px; ")
        self.btn_delete_point.setEnabled(False)

        row2_layout.addWidget(self.btn_edit_point)
        row2_layout.addWidget(self.btn_delete_point)
        layout.addLayout(row2_layout)

        # เส้นแบ่งโซน
        layout.addSpacing(5)
        line2 = QFrame()
        line2.setFrameShape(QFrame.HLine)
        line2.setFrameShadow(QFrame.Sunken)
        layout.addWidget(line2)
        layout.addSpacing(5)

        # --- โซนที่ 3: ระบบควบคุมและย้อนกลับ ---
        row3_layout = QHBoxLayout()
        self.btn_reset = QPushButton("🔄 Reset / Cancel")
        self.btn_reset.setStyleSheet("font-weight: bold; height: 30px; background-color: #f5f5f5;")

        self.btn_undo = QPushButton("↩️ Undo (ย้อนกลับ)")
        self.btn_undo.setStyleSheet("font-weight: bold; height: 30px; background-color: #ffebee; color: #c62828;")

        row3_layout.addWidget(self.btn_reset)
        row3_layout.addWidget(self.btn_undo)
        layout.addLayout(row3_layout)

        self.btn_save = QPushButton("💾 บันทึกการแก้ไขทั้งหมด (Save)")
        self.btn_save.setStyleSheet("height: 45px; font-weight: bold; background-color: #c8e6c9; color: #2e7d32; font-size: 14px;")
        self.btn_save.setEnabled(False)
        layout.addWidget(self.btn_save)

        layout.addSpacing(5)
        line3 = QFrame()
        line3.setFrameShape(QFrame.HLine)
        line3.setFrameShadow(QFrame.Sunken)
        layout.addWidget(line3)
        layout.addSpacing(5)

        row_util_layout = QHBoxLayout()
        self.btn_upd = QPushButton("🚀 Check Update")
        self.btn_upd.setStyleSheet("height: 30px; background-color: #f3e5f5;")
        self.btn_shortcut = QPushButton("⌨ ตั้งค่าคีย์ลัด")
        self.btn_shortcut.setStyleSheet("height: 30px; background-color: #eceff1;")
        row_util_layout.addWidget(self.btn_upd)
        row_util_layout.addWidget(self.btn_shortcut)
        layout.addLayout(row_util_layout)

        lbl_author = QLabel("จัดทำโดย: ชาคฤตย์ จันทรสุกศรี")
        lbl_dept = QLabel("กองเทคโนโลยีทำแผนที่ กรมที่ดิน")

        info_font = lbl_author.font()
        info_font.setPointSize(9)
        lbl_author.setFont(info_font)
        lbl_dept.setFont(info_font)
        lbl_author.setAlignment(Qt.AlignCenter)
        lbl_dept.setAlignment(Qt.AlignCenter)

        layout.addWidget(lbl_author)
        layout.addWidget(lbl_dept)

    def update_display_path(self, full_path):
        name = _build_name_from_path(full_path)
        self.UTMMAP.setText(name if name else "---")

    def browse_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "เลือกโฟลเดอร์", self.line_path.text())
        if folder:
            self.line_path.setText(folder)


class FileSelectDialog(QDialog):
    def __init__(self, file_list, title, label_text, parent=None):
        super(FileSelectDialog, self).__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(550)
        layout = QVBoxLayout(self)
        self.list_widget = QListWidget()
        for path in file_list:
            self.list_widget.addItem(path)
        self.list_widget.setSelectionMode(QAbstractItemView.SingleSelection)
        layout.addWidget(QLabel(f"<b>{label_text}</b>"))
        layout.addWidget(self.list_widget)
        btn_ok = QPushButton("ตกลง")
        btn_ok.clicked.connect(self.accept)
        layout.addWidget(btn_ok)

    def get_selected_file(self):
        selected = self.list_widget.selectedItems()
        return selected[0].text() if selected else None


# ---------------------------------------------------------------------------
# Helper function (module-level) — สร้างชื่อจาก path
# แก้ปัญหา: logic ซ้ำกันระหว่าง update_display_path() และ download_template_gpkg()
# ---------------------------------------------------------------------------
def _path_parts(folder_path):
    """แยกส่วนประกอบจากโครงสร้างโฟลเดอร์ -> dict โดย key ตรงกับชื่อฟิลด์ใน template
    (utmmap1-4, utmscale, landno) คืน None ถ้า path มีชั้นไม่ครบ"""
    parts = os.path.normpath(folder_path).split(os.sep)
    if len(parts) > 5:
        return {
            'utmmap1': parts[-6],
            'utmmap2': parts[-5],
            'utmmap3': parts[-4],
            'utmscale': parts[-3],
            'utmmap4': parts[-2],
            'landno': parts[-1],
        }
    return None


def _build_name_from_path(folder_path):
    """
    แปลง path โฟลเดอร์ให้เป็นชื่องาน เช่น 'A B C-D(SCALE)_LANDNO'
    คืนค่าสตริงชื่อ หรือ None ถ้า path ไม่ครบ
    """
    p = _path_parts(folder_path)
    if p:
        return f"{p['utmmap1']} {p['utmmap2']} {p['utmmap3']}-{p['utmmap4']}({p['utmscale']})_{p['landno']}"
    return None


def _parse_version(text):
    """แปลงสตริงเวอร์ชัน '1.0.10' -> (1, 0, 10) เพื่อเทียบเชิงตัวเลข
    แก้บั๊ก: การเทียบ string ทำให้ '1.0.10' < '1.0.9' (ผิด)"""
    try:
        return tuple(int(p) for p in str(text).strip().split('.'))
    except (ValueError, AttributeError):
        return ()


def _prompt_point_name(parent, title, label_text, initial_value,
                       last_pos=None, accent="#3498db", label_color="#2c3e50"):
    """แสดง dialog ถามชื่อหมุด — รวม logic ที่ซ้ำกันระหว่างเครื่องมือแก้ไข/แทรกหมุด
    คืนค่า (accepted: bool, value: str, dialog_pos)"""
    dialog = QInputDialog(parent)
    dialog.setWindowTitle(title)
    dialog.setLabelText(label_text)
    dialog.setTextValue(initial_value)
    if last_pos:
        dialog.move(last_pos)
    dialog.resize(300, 350)
    dialog.setStyleSheet(f"""
        QLabel {{
            font-size: 16px; font-weight: bold; color: {label_color}; margin-bottom: 5px;
        }}
        QLineEdit {{
            font-size: 20px; padding: 10px; border: 2px solid {accent};
            border-radius: 6px; background-color: #ffffff;
        }}
        QPushButton {{
            font-size: 15px; min-width: 100px; min-height: 35px;
            background-color: #f8f9fa; border: 1px solid #ced4da; border-radius: 4px;
        }}
        QPushButton:hover {{ background-color: #e2e6ea; }}
    """)
    accepted = bool(dialog.exec_())
    return accepted, dialog.textValue(), dialog.pos()


class GPKGEditor:
    def __init__(self, iface):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        self.dlg = GPKGEditorDialog(self.iface.mainWindow())
        self.loaded_layer_ids = []
        self.point_layer = None
        self.poly_layer = None
        self.current_root_path = None   # โฟลเดอร์งานที่โหลดอยู่ — ใช้เติม attr ตอนบันทึก
        self.edit_tool = None
        # ระบบ Undo ทนทาน (เก็บ operation เป็น index-delta ต่อเลเยอร์)
        self.op_history = []
        self._op_baseline = None
        self._edit_end = {}
        self._signal_layers = set()
        self._signal_conns = []
        self._shortcuts = []

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.action = QAction(QIcon(icon_path), "เปิด GPKG Editor", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        # BUG FIX #1: ลบการลงทะเบียนซ้ำ — เรียกแค่ครั้งเดียว
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&GPKG Editor", self.action)

        self.dlg.btn_upd.clicked.connect(self.update_plugin)
        self.dlg.btn_load.clicked.connect(self.process_load)
        self.dlg.btn_edit_point.clicked.connect(self.activate_edit_tool)
        self.dlg.btn_move_point.clicked.connect(self.activate_move_tool)
        self.dlg.btn_reset.clicked.connect(self.reset_to_select)
        self.dlg.btn_undo.clicked.connect(self.undo_action)
        self.dlg.btn_save.clicked.connect(self.save_changes)
        self.dlg.btn_insert_point.clicked.connect(self.activate_insert_tool)
        self.dlg.btn_delete_point.clicked.connect(self.activate_delete_tool)
        self.dlg.btn_create_init.clicked.connect(self.activate_initial_draw_tool)
        self.dlg.btn_delete_all.clicked.connect(self.delete_all_features)
        self.dlg.btn_shortcut.clicked.connect(self.open_shortcut_settings)
        self._load_shortcuts()

    # -----------------------------------------------------------------------
    # NEW FEATURE: ตรวจสอบงานที่ยังไม่บันทึกก่อนโหลดงานใหม่
    # -----------------------------------------------------------------------
    def _check_unsaved_changes(self):
        """
        ตรวจสอบว่า layer ที่โหลดอยู่มีการแก้ไขที่ยังไม่บันทึกหรือไม่

        Returns:
            True  — ดำเนินการต่อได้ (ไม่มีงานค้าง, บันทึกแล้ว, หรือ Discard)
            False — ผู้ใช้กด Cancel → ยกเลิกการโหลดงานใหม่
        """
        layers_to_check = [
            layer for layer in [self.point_layer, self.poly_layer]
            if layer and layer.isEditable() and layer.isModified()
        ]

        if not layers_to_check:
            return True  # ไม่มีงานค้าง → ดำเนินการต่อได้เลย

        layer_names = ", ".join(l.name() for l in layers_to_check)
        reply = QMessageBox.question(
            self.dlg,
            "⚠️ มีงานที่ยังไม่ได้บันทึก",
            f"พบการแก้ไขที่ยังไม่ได้บันทึกใน:\n  • {layer_names}\n\n"
            f"ต้องการบันทึกก่อนโหลดงานใหม่หรือไม่?",
            QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel,
            QMessageBox.Save  # default button
        )

        if reply == QMessageBox.Save:
            self.save_changes()
            return True
        elif reply == QMessageBox.Discard:
            # ผู้ใช้เลือกทิ้งการแก้ไข → rollback ก่อนดำเนินการต่อ
            for layer in layers_to_check:
                layer.rollBack()
            return True
        else:
            # ผู้ใช้กด Cancel → หยุดการโหลด
            return False

    def update_plugin(self):
        V_URL = "https://raw.githubusercontent.com/chakrit39/GPKG_Editor/refs/heads/main/version.txt"
        Z_URL = "https://github.com/chakrit39/GPKG_Editor/raw/refs/heads/main/GPKG_Editor.zip"

        try:
            # 1. ตรวจสอบเวอร์ชัน (requests บล็อก UI ได้ถึง 5 วิ — แสดง busy cursor บอกผู้ใช้)
            QApplication.setOverrideCursor(Qt.WaitCursor)
            try:
                res = requests.get(V_URL, timeout=5)
            finally:
                QApplication.restoreOverrideCursor()
            remote_version = res.text.strip()

            # เทียบเชิงตัวเลข (1.0.10 > 1.0.9) แทนการเทียบ string
            if _parse_version(remote_version) > _parse_version(self.dlg.version):
                reply = QMessageBox.question(
                    self.dlg, "พบเวอร์ชันใหม่",
                    f"เวอร์ชันใหม่ ({remote_version}) พร้อมใช้งาน\nคุณต้องการอัปเดตทันทีหรือไม่?",
                    QMessageBox.Yes | QMessageBox.No
                )

                if reply == QMessageBox.Yes:
                    r = requests.get(Z_URL, timeout=60, stream=True)
                    total = int(r.headers.get('content-length', 0))

                    # Progress Dialog — ถ้ารู้ขนาดไฟล์จะแสดงเป็น % ได้ (ไม่งั้น indeterminate)
                    progress = QProgressDialog("กำลังดาวน์โหลด...", "ยกเลิก", 0, total, self.dlg)
                    progress.setWindowTitle("อัปเดตปลั๊กอิน")
                    progress.setWindowModality(Qt.WindowModal)
                    progress.show()

                    chunks = []
                    downloaded = 0
                    for chunk in r.iter_content(chunk_size=8192):
                        if progress.wasCanceled():
                            r.close()
                            progress.close()
                            return
                        if chunk:
                            chunks.append(chunk)
                            downloaded += len(chunk)
                            if total:
                                progress.setValue(downloaded)
                        # ให้ UI ตอบสนอง (repaint + รับปุ่มยกเลิก) ระหว่างดาวน์โหลด
                        QApplication.processEvents()
                    progress.close()

                    z = zipfile.ZipFile(io.BytesIO(b"".join(chunks)))
                    plugin_dir = os.path.dirname(os.path.dirname(__file__))
                    z.extractall(plugin_dir)

                    QMessageBox.information(self.dlg, "อัปเดตสำเร็จ",
                                            "อัปเดตปลั๊กอินเรียบร้อยแล้ว!\nกรุณา Restart QGIS เพื่อเริ่มใช้งานเวอร์ชันใหม่")
            else:
                QMessageBox.information(self.dlg, "อัปเดต", "คุณกำลังใช้งานเวอร์ชันล่าสุดแล้ว")

        except Exception as e:
            QMessageBox.warning(self.dlg, "เกิดข้อผิดพลาด", f"ไม่สามารถตรวจสอบการอัปเดตได้:\n{str(e)}")

    # =======================================================================
    # What's New popup — เด้งสรุปสิ่งที่เปลี่ยนเมื่อเปิดครั้งแรกหลังเวอร์ชันใหม่
    # =======================================================================
    def _show_whats_new(self):
        s = QSettings()
        key = "GPKGEditor/lastSeenVersion"
        last = s.value(key, "", str)
        if _parse_version(self.dlg.version) <= _parse_version(last):
            return                          # เคยเห็นแล้ว / ไม่ใช่เวอร์ชันใหม่
        s.setValue(key, self.dlg.version)   # บันทึกทันทีกันเด้งซ้ำ
        if last:
            last_idx = next((i for i, (v, _) in enumerate(CHANGELOG)
                             if _parse_version(v) <= _parse_version(last)), len(CHANGELOG))
            new_entries = CHANGELOG[:max(last_idx, 3)]
            head = f"อัปเดตเป็นเวอร์ชัน {self.dlg.version} แล้ว 🎉"
        else:
            new_entries = CHANGELOG[:3]
            head = f"ยินดีต้อนรับสู่เวอร์ชัน {self.dlg.version} 🎉"
        if not new_entries:
            return
        rows = []
        for v, items in new_entries:
            rows.append(f"<b>v{v}</b>")
            rows += [f"&nbsp;&nbsp;• {it}" for it in items]
            rows.append("")
        box = QMessageBox(self.dlg or self.iface.mainWindow())
        box.setWindowTitle("GPKG Editor — มีอะไรใหม่ ✨")
        box.setTextFormat(Qt.RichText)
        box.setText(head)
        box.setInformativeText("<br>".join(rows))
        box.setStandardButtons(QMessageBox.Ok)
        box.exec_()

    # =======================================================================
    # Shortcut — ตั้งคีย์ลัดให้ปุ่มต่าง ๆ (ทำงานทั้งแอปขณะใช้ QGIS)
    # =======================================================================
    def _shortcut_actions(self):
        """รายการ action ที่ตั้ง shortcut ได้: (id, label, callable)"""
        return [
            ("load", "🚀 สแกนและโหลดข้อมูล", self.process_load),
            ("create_init", "🆕 สร้างรูปแปลงและหมุดใหม่", self.activate_initial_draw_tool),
            ("delete_all", "🧹 ลบรูปแปลงและหมุดทั้งหมด", self.delete_all_features),
            ("move", "📍 ย้ายหมุด", self.activate_move_tool),
            ("insert", "➕ แทรกหมุด", self.activate_insert_tool),
            ("edit", "✏️ แก้ไขชื่อหมุด", self.activate_edit_tool),
            ("delete", "🗑️ ลบหมุด", self.activate_delete_tool),
            ("reset", "🔄 Reset / Cancel", self.reset_to_select),
            ("undo", "↩️ Undo", self.undo_action),
            ("save", "💾 บันทึก", self.save_changes),
        ]

    def _load_shortcuts(self):
        """อ่าน QSettings -> สร้าง QShortcut ผูกกับ main window"""
        for sc in getattr(self, "_shortcuts", []):
            try:
                sc.setParent(None)
                sc.deleteLater()
            except Exception:
                pass
        self._shortcuts = []
        s = QSettings()
        k = "GPKGEditor/Shortcut/"
        mw = self.iface.mainWindow()
        for aid, label, slot in self._shortcut_actions():
            seq = s.value(k + aid, "", str)
            if not seq:
                continue
            sc = QShortcut(QKeySequence(seq), mw)
            sc.setContext(Qt.ApplicationShortcut)
            sc.activated.connect(slot)
            self._shortcuts.append(sc)

    def open_shortcut_settings(self):
        """popup ตั้งค่า shortcut แต่ละปุ่ม"""
        dlg = QDialog(self.dlg)
        dlg.setWindowTitle("⌨ ตั้งค่า Shortcut")
        dlg.setMinimumWidth(380)
        v = QVBoxLayout(dlg)
        v.addWidget(QLabel("คลิกในช่องแล้วกดคีย์ที่ต้องการ (เว้นว่าง = ไม่ใช้)\nทำงานทั้งแอปขณะใช้ QGIS"))
        s = QSettings()
        k = "GPKGEditor/Shortcut/"
        form = QFormLayout()
        editors = {}
        for aid, label, slot in self._shortcut_actions():
            ed = QKeySequenceEdit(QKeySequence(s.value(k + aid, "", str)))
            editors[aid] = ed
            btn_clr = QPushButton("✖")
            btn_clr.setFixedWidth(28)
            btn_clr.clicked.connect(ed.clear)
            row = QHBoxLayout()
            row.addWidget(ed, 1)
            row.addWidget(btn_clr, 0)
            w = QWidget()
            w.setLayout(row)
            form.addRow(label + ":", w)
        inner = QWidget()
        inner.setLayout(form)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(inner)
        v.addWidget(scroll)
        btns = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        v.addWidget(btns)
        btns.accepted.connect(dlg.accept)
        btns.rejected.connect(dlg.reject)
        if dlg.exec_() != QDialog.Accepted:
            return

        qgis_keys = self._qgis_shortcut_keys()
        seen, dup, conflict = {}, set(), set()
        for aid, ed in editors.items():
            seq = ed.keySequence().toString()
            if seq:
                if seq in seen:
                    dup.add(seq)
                seen[seq] = aid
                if seq in qgis_keys:
                    conflict.add(seq)
            s.setValue(k + aid, seq)
        self._load_shortcuts()
        msg = "บันทึก shortcut แล้ว ✅"
        if dup:
            msg += f"\n⚠️ คีย์ซ้ำกันเองในปลั๊กอิน: {', '.join(sorted(dup))}"
        if conflict:
            ck = ", ".join(sorted(conflict))
            ans = QMessageBox.question(
                self.dlg, "คีย์ชนกับ QGIS",
                f"คีย์เหล่านี้ QGIS ใช้อยู่: {ck}\n"
                "ถ้าปล่อยไว้ Qt จะถือว่ากำกวม → ปุ่มลัดอาจไม่ทำงาน\n\n"
                "ต้องการให้ปลดคีย์เดิมของ QGIS ออกเพื่อให้ปลั๊กอินใช้คีย์นี้ได้ไหม?\n"
                "(เปลี่ยนคีย์ลัด QGIS ถาวร — ย้อนคืนได้ที่ Settings → Keyboard Shortcuts)",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ans == QMessageBox.Yes:
                released = self._release_qgis_shortcuts(conflict)
                self._load_shortcuts()
                if released:
                    msg += f"\n✅ ปลดคีย์ QGIS แล้ว: {', '.join(sorted(released))}"
                left = conflict - released
                if left:
                    msg += f"\n⚠️ ปลดไม่ได้: {', '.join(sorted(left))} (แก้เองที่ Settings → Keyboard Shortcuts)"
            else:
                msg += f"\n⚠️ ยังชนกับ QGIS: {ck} (ปุ่มลัดอาจไม่ทำงาน)"
        QMessageBox.information(self.dlg, "Shortcut", msg)

    def _release_qgis_shortcuts(self, keys):
        """ปลดคีย์เดิมของ QGIS ที่ชน ผ่าน QgsShortcutsManager -> set คีย์ที่ปลดได้"""
        released = set()
        try:
            from qgis.gui import QgsGui
            mgr = QgsGui.shortcutsManager()
        except Exception:
            return released
        for key in keys:
            seq = QKeySequence(key)
            obj = None
            for getter in ("objectForSequence", "actionForSequence", "shortcutForSequence"):
                if hasattr(mgr, getter):
                    try:
                        obj = getattr(mgr, getter)(seq)
                    except Exception:
                        obj = None
                    if obj is not None:
                        break
            if obj is not None:
                try:
                    if mgr.setKeySequence(obj, ""):
                        released.add(key)
                except Exception:
                    pass
        return released

    def _qgis_shortcut_keys(self):
        """รวมคีย์ลัดที่ QGIS ใช้อยู่ (ไว้เตือนเมื่อตั้งคีย์ชนกัน)"""
        keys = set()
        try:
            from qgis.gui import QgsGui
            mgr = QgsGui.shortcutsManager()
            for a in mgr.listActions():
                t = a.shortcut().toString()
                if t:
                    keys.add(t)
            for sc in mgr.listShortcuts():
                t = sc.key().toString()
                if t:
                    keys.add(t)
        except Exception:
            pass
        try:
            for a in self.iface.mainWindow().findChildren(QAction):
                t = a.shortcut().toString()
                if t:
                    keys.add(t)
        except Exception:
            pass
        return keys

    # =======================================================================
    # Undo ทนทาน — เก็บ operation เป็น index-delta ของ undo-stack ต่อเลเยอร์
    # =======================================================================
    def _watch_layer_editing(self, lyr):
        """ต่อ signal commit/rollback ของเลเยอร์ (ครั้งเดียวต่อเลเยอร์)
        เพื่อรู้ว่าตอนปิด edit กด Save หรือ Discard"""
        if lyr is None:
            return
        lid = lyr.id()
        if lid in self._signal_layers:
            return
        self._signal_layers.add(lid)

        def on_commit(_lid=lid):
            self._edit_end[_lid] = 'commit'

        def on_rollback(_lid=lid):
            self._edit_end[_lid] = 'rollback'

        def on_start(_lid=lid):
            self._edit_end.pop(_lid, None)

        for sig_name, slot in (("afterCommitChanges", on_commit),
                               ("afterRollBack", on_rollback),
                               ("editingStarted", on_start)):
            sig = getattr(lyr, sig_name, None)
            if sig is None:
                continue
            try:
                sig.connect(slot)
                self._signal_conns.append((sig, slot))
            except Exception:
                pass

    def _op_begin(self, layers):
        """บันทึกตำแหน่ง undo-stack ปัจจุบันของแต่ละเลเยอร์ ก่อนเริ่ม operation"""
        baseline = {}
        for lyr in layers:
            if lyr is None:
                continue
            try:
                baseline[lyr.id()] = (lyr, lyr.undoStack().index())
                self._watch_layer_editing(lyr)
            except Exception:
                pass
        self._op_baseline = baseline

    def _op_commit(self):
        """ปิด operation: เลเยอร์ไหนถูก push undo เพิ่ม (delta>0) เก็บเป็น 1 รายการในประวัติ"""
        base = self._op_baseline
        self._op_baseline = None
        if not base:
            return
        op = []
        for lyr, before in base.values():
            try:
                delta = lyr.undoStack().index() - before
            except Exception:
                delta = 0
            if delta > 0:
                op.append((lyr, delta))
        if op:
            self.op_history.append(op)
            if len(self.op_history) > 100:
                self.op_history.pop(0)

    def activate_delete_tool(self):
        if not self.point_layer or not self.poly_layer:
            return
        self.delete_tool = PointDeleteTool(self, self.canvas, self.iface, self.point_layer, self.poly_layer)
        self.canvas.setMapTool(self.delete_tool)

    def activate_insert_tool(self):
        if self.point_layer and self.poly_layer:
            self.insert_tool = PointInsertTool(self, self.iface, self.point_layer, self.poly_layer)
            self.canvas.setMapTool(self.insert_tool)

    def _apply_path_attributes(self):
        """เติม utmmap1-4 / utmscale / landno จากโครงสร้างโฟลเดอร์ลงทุก feature ก่อนบันทึก
        ฟิลด์ตัวเลข (Integer64) จะเติมเฉพาะเมื่อชื่อโฟลเดอร์แปลงเป็นตัวเลขได้ — กัน commit พัง"""
        vals = _path_parts(self.current_root_path) if self.current_root_path else None
        if not vals:
            return
        for layer in (self.point_layer, self.poly_layer):
            if not (layer and layer.isValid() and layer.isEditable()):
                continue
            fields = layer.fields()
            idx_val = {}
            for fname, raw in vals.items():
                fidx = fields.lookupField(fname)
                if fidx == -1:
                    continue
                val = raw
                if fields.at(fidx).isNumeric():
                    try:
                        val = int(raw)
                    except (TypeError, ValueError):
                        continue
                idx_val[fidx] = val
            if not idx_val:
                continue
            layer.beginEditCommand("Fill attributes from path")
            try:
                for feat in layer.getFeatures():
                    for fidx, val in idx_val.items():
                        if feat.attribute(fidx) != val:
                            layer.changeAttributeValue(feat.id(), fidx, val)
                layer.endEditCommand()
            except Exception:
                layer.destroyEditCommand()

    def save_changes(self):
        """บันทึกการแก้ไขลงไฟล์ GPKG และหยุดโหมดการแก้ไข"""
        # เติมค่าฟิลด์จากโครงสร้างโฟลเดอร์ให้ทุก feature ก่อน commit
        self._apply_path_attributes()
        layers_to_save = [self.point_layer, self.poly_layer]
        success_count = 0
        failed = []

        for layer in layers_to_save:
            if layer and layer.isEditable():
                if layer.commitChanges():
                    success_count += 1
                else:
                    # ห้าม rollBack — commit ล้มเหลวเกิดง่ายบนโฟลเดอร์แชร์ (ไฟล์ถูกล็อก/เน็ตสะดุด)
                    # เก็บงานไว้ในหน่วยความจำให้ผู้ใช้แก้สาเหตุแล้วกดบันทึกซ้ำได้
                    failed.append((layer, "\n".join(layer.commitErrors())))

        if failed:
            names = ", ".join(l.name() for l, _ in failed)
            details = "\n\n".join(e for _, e in failed if e)
            QMessageBox.warning(
                self.dlg, "บันทึกไม่สำเร็จ",
                f"บันทึกเลเยอร์ {names} ไม่สำเร็จ\n\n"
                "งานที่แก้ไขยังอยู่ครบ ยังไม่ถูกทิ้ง — ตรวจสอบว่าไฟล์ไม่ถูกเปิดหรือล็อก"
                "โดยเครื่อง/โปรแกรมอื่น แล้วกดบันทึกอีกครั้ง"
                + (f"\n\nรายละเอียด:\n{details}" if details else ""))

        if success_count > 0:
            self.iface.messageBar().pushMessage("สำเร็จ", "บันทึกข้อมูลลง Geopackage เรียบร้อยแล้ว", level=0, duration=3)
            # commitChanges ล้าง undo-stack ของ QGIS -> ประวัติ op เก่าย้อนไม่ได้แล้ว เคลียร์ทิ้ง
            self.op_history.clear()
            self._op_baseline = None
            # เปิดโหมดแก้ไขต่อเพื่อทำงานต่อได้ทันที (เฉพาะเลเยอร์ที่มีอยู่จริง)
            for layer in layers_to_save:
                if layer and not layer.isEditable():
                    layer.startEditing()

    def undo_action(self):
        """ย้อน operation ล่าสุดของปลั๊กอิน — ย้อนแต่ละเลเยอร์ตามจำนวน step ที่มัน push จริง
        แก้บั๊กเดิม: undo ครั้งเดียวเคยย้อนทั้ง 2 เลเยอร์เสมอ ทำให้เลเยอร์ที่ไม่เกี่ยว (เช่น
        เปลี่ยนชื่อหมุดที่แตะแค่ point) ถูกย้อน poly ผิดไปด้วย"""
        if not self.op_history:
            self.iface.messageBar().pushMessage("Undo", "ไม่มีรายการล่าสุดให้ย้อนกลับ", level=1, duration=3)
            return

        op = self.op_history[-1]   # ยังไม่ pop เผื่อบล็อก/ยกเลิก
        live, saved_gone, disc_gone, unknown_gone = [], [], [], []
        for lyr, n in op:
            if lyr is None:
                continue
            try:
                if lyr.isEditable() and lyr.undoStack().canUndo():
                    live.append((lyr, n))
                else:
                    ev = self._edit_end.get(lyr.id())
                    if ev == 'rollback':
                        disc_gone.append(lyr)
                    elif ev == 'commit':
                        saved_gone.append(lyr)
                    else:
                        unknown_gone.append(lyr)
            except Exception:
                unknown_gone.append(lyr)

        # เคสปกติ: ทุกเลเยอร์ยังเปิดอยู่ -> ย้อนตามจำนวน step ของแต่ละเลเยอร์
        if not (saved_gone or disc_gone or unknown_gone):
            self.op_history.pop()
            for lyr, n in live:
                stack = lyr.undoStack()
                for _ in range(n):
                    if not stack.canUndo():
                        break
                    stack.undo()
                lyr.triggerRepaint()
            self.canvas.refresh()
            self.iface.messageBar().pushMessage("Undo", "ย้อนกลับการทำงานล่าสุดเรียบร้อยแล้ว", level=0, duration=3)
            return

        # มีเลเยอร์ปิด+Save (หรือไม่รู้สถานะ) -> บล็อก เพราะย้อนเลเยอร์เดียวจะไม่ตรงกัน
        if saved_gone or unknown_gone:
            names = ", ".join(l.name() for l in (saved_gone + unknown_gone))
            QMessageBox.warning(
                self.dlg, "ย้อนกลับไม่ได้",
                f"เลเยอร์ '{names}' ถูกปิดแก้ไข/บันทึกไปแล้ว — ประวัติ undo หายไป\n\n"
                "ย้อนอัตโนมัติไม่ได้ เพราะจะทำให้ 2 เลเยอร์ไม่ตรงกัน")
            return

        # เลเยอร์ที่หายเป็น Discard ทั้งหมด -> ข้อมูลกลับจุดเริ่มอยู่แล้ว
        if not live:
            self.op_history.pop()
            self.iface.messageBar().pushMessage(
                "Undo", "เลเยอร์ถูกปิดแบบไม่บันทึก — ข้อมูลกลับจุดเริ่มแล้ว", level=0, duration=3)
            return

        # มีทั้ง Discard และเลเยอร์ที่ยังเปิด -> ถามว่าจะย้อนเลเยอร์ที่เปิดกลับจุดเริ่มให้ตรงกันไหม
        disc_names = ", ".join(l.name() for l in disc_gone)
        live_names = ", ".join(l.name() for l, _ in live)
        ans = QMessageBox.question(
            self.dlg, "เลเยอร์ถูกปิดแบบไม่บันทึก",
            f"เลเยอร์ '{disc_names}' ถูกปิดแก้ไขแบบไม่บันทึก → ข้อมูลกลับ 'จุดเริ่มเปิดแก้ไข' แล้ว\n\n"
            f"ต้องการย้อนเลเยอร์ '{live_names}' กลับจุดเริ่มด้วยเพื่อให้ตรงกันไหม?\n"
            "⚠️ งานทั้งหมดในเลเยอร์นี้ตั้งแต่เปิดแก้ไขจะถูกย้อนทิ้ง",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if ans == QMessageBox.Yes:
            for lyr, _n in live:
                stack = lyr.undoStack()
                while stack.canUndo():
                    stack.undo()
                lyr.triggerRepaint()
            self.op_history.clear()
            self.canvas.refresh()
            self.iface.messageBar().pushMessage("Undo", "ย้อนทั้งสองเลเยอร์กลับจุดเริ่มแล้ว", level=0, duration=3)

    def reset_to_select(self):
        """คืนค่าเครื่องมือกลับไปเป็นลูกศรเลือก (Select) มาตรฐานของ QGIS"""
        # BUG FIX #3: ป้องกัน crash เมื่อ tool ยังไม่ถูก activate
        for tool_attr in ('edit_tool', 'move_tool', 'delete_tool', 'insert_tool', 'init_draw_tool'):
            tool = getattr(self, tool_attr, None)
            if tool is not None:
                self.canvas.unsetMapTool(tool)

        self.iface.actionPan().trigger()
        self.iface.messageBar().pushMessage("ระบบ", "คืนค่าเป็นเครื่องมือปกติแล้ว", level=0, duration=2)

    def activate_move_tool(self):
        if self.point_layer and self.poly_layer:
            self.move_tool = PointMoveTool(self, self.iface, self.point_layer, self.poly_layer)
            self.canvas.setMapTool(self.move_tool)
            self.iface.messageBar().pushMessage("ระบบ", "คลิกค้างที่จุดแล้วลากเพื่อย้ายตำแหน่ง", level=0, duration=3)

    def unload(self):
        self.iface.removePluginMenu("&GPKG Editor", self.action)
        self.iface.removeToolBarIcon(self.action)
        # ปลด map tool ที่ค้าง + ตัด signal + ปิดหน้าต่าง กัน handler ซ้อนตอน reload ปลั๊กอิน
        for tool_attr in ('edit_tool', 'move_tool', 'delete_tool', 'insert_tool', 'init_draw_tool'):
            tool = getattr(self, tool_attr, None)
            if tool is not None:
                self.canvas.unsetMapTool(tool)
        self._disconnect_layer_signals()
        self.dlg.close()
        # เก็บกวาด QShortcut ที่ผูกกับ main window ไม่ให้ค้างหลัง unload
        for sc in getattr(self, "_shortcuts", []):
            try:
                sc.setParent(None)
                sc.deleteLater()
            except Exception:
                pass
        self._shortcuts = []

    def run(self):
        self.dlg.show()
        self._show_whats_new()

    def _disconnect_layer_signals(self):
        """ตัด signal ที่ต่อกับเลเยอร์เก่า ไม่ให้ slot/อ็อบเจ็กต์ที่ถูกลบแล้วค้างอยู่"""
        for sig, slot in self._signal_conns:
            try:
                sig.disconnect(slot)
            except Exception:
                pass
        self._signal_conns = []

    def clear_previous_layers(self):
        self._disconnect_layer_signals()
        if self.loaded_layer_ids:
            QgsProject.instance().removeMapLayers(self.loaded_layer_ids)
            self.loaded_layer_ids = []
            self.point_layer = None
            self.poly_layer = None
        # โหลดงานใหม่ -> ล้างประวัติ undo และสถานะติดตามเลเยอร์เก่า
        self.op_history = []
        self._op_baseline = None
        self._edit_end = {}
        self._signal_layers = set()
        self.current_root_path = None

    def setup_snapping(self, layers):
        config = QgsProject.instance().snappingConfig()
        config.setEnabled(True)
        config.setMode(QgsSnappingConfig.AdvancedConfiguration)
        config.clearIndividualLayerSettings()

        for lyr in layers:
            if lyr:
                setting = QgsSnappingConfig.IndividualLayerSettings()
                setting.setEnabled(True)
                setting.type = QgsSnappingConfig.Vertex | QgsSnappingConfig.Segment
                setting.setTolerance(SNAP_TOL_PX)
                setting.setUnits(QgsTolerance.Pixels)
                config.setIndividualLayerSettings(lyr, setting)

        QgsProject.instance().setSnappingConfig(config)

    def activate_edit_tool(self):
        if self.point_layer:
            self.edit_tool = PointEditTool(self, self.iface, self.point_layer)
            self.canvas.setMapTool(self.edit_tool)

    def activate_initial_draw_tool(self):
        # กันคีย์ลัดเรียกก่อนโหลดข้อมูล (ปุ่มถูก disable แต่ shortcut ไม่ผ่านปุ่ม)
        if not self.point_layer or not self.poly_layer:
            return

        # ตรวจสอบว่าเลเยอร์ว่างจริงไหม
        point_count = self.point_layer.featureCount()
        poly_count = self.poly_layer.featureCount()

        if point_count > 0 or poly_count > 0:
            QMessageBox.warning(
                self.dlg,
                "ไม่อนุญาต",
                f"เครื่องมือนี้ใช้สำหรับสร้างข้อมูลใหม่เท่านั้น\nขณะนี้พบ Point: {point_count} และ Polygon: {poly_count} features"
            )
            return

        self.init_draw_tool = InitialDrawTool(self, self.iface, self.point_layer, self.poly_layer)
        self.canvas.setMapTool(self.init_draw_tool)

        self.iface.messageBar().pushMessage(
            "วิธีใช้งาน",
            "คลิกซ้ายวางจุด • คลิกขวาหรือคลิกจุดแรกซ้ำ = จบแปลง • "
            "Shift+คลิกขวา = ปิดก้อนนี้แล้ววาดก้อนถัดไป (โฉนดที่มีหลายก้อนแยกกัน)",
            level=0,
            duration=6
        )

    def delete_all_features(self):
        """ลบรูปแปลงและหมุดทั้งหมดออกจากทั้งสองเลเยอร์ (undo ได้, ยังไม่ commit)"""
        if not self.point_layer or not self.poly_layer:
            return

        point_count = self.point_layer.featureCount()
        poly_count = self.poly_layer.featureCount()

        if point_count == 0 and poly_count == 0:
            QMessageBox.information(self.dlg, "ไม่มีข้อมูล", "ไม่มีรูปแปลงหรือหมุดให้ลบ")
            return

        reply = QMessageBox.question(
            self.dlg, "⚠️ ยืนยันการลบทั้งหมด",
            f"<b>ต้องการลบข้อมูลทั้งหมดหรือไม่?</b><br><br>"
            f"  • หมุด (Point): {point_count}<br>"
            f"  • รูปแปลง (Polygon): {poly_count}<br><br>"
            f"<i>สามารถกด Undo หรือ Reset ก่อนบันทึกได้</i>",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return

        if not self.point_layer.isEditable():
            self.point_layer.startEditing()
        if not self.poly_layer.isEditable():
            self.poly_layer.startEditing()

        self._op_begin([self.point_layer, self.poly_layer])
        self.point_layer.beginEditCommand("Delete All Points")
        self.poly_layer.beginEditCommand("Delete All Polygons")
        try:
            self.point_layer.deleteFeatures(self.point_layer.allFeatureIds())
            self.poly_layer.deleteFeatures(self.poly_layer.allFeatureIds())
            self.point_layer.endEditCommand()
            self.poly_layer.endEditCommand()
            self._op_commit()

            self.point_layer.triggerRepaint()
            self.poly_layer.triggerRepaint()
            self.canvas.refresh()
            self.iface.messageBar().pushMessage(
                "สำเร็จ", "ลบรูปแปลงและหมุดทั้งหมดแล้ว (ยังไม่บันทึก)", level=0, duration=3)
        except Exception as e:
            self.point_layer.destroyEditCommand()
            self.poly_layer.destroyEditCommand()
            self._op_commit()
            self.iface.messageBar().pushMessage("Error", f"ลบไม่สำเร็จ: {str(e)}", level=2)

    def download_template_gpkg(self, folder_path, img_path):
        """ดึงไฟล์ Template จาก GitHub มาวางในโฟลเดอร์ที่เลือก"""
        TEMPLATE_URL = "https://github.com/chakrit39/GPKG_Editor/raw/refs/heads/main/template.gpkg"

        # CODE QUALITY #7: ใช้ helper function แทน logic ซ้ำ
        name = _build_name_from_path(folder_path) or "Error_Path"
        img_name = "_" + os.path.splitext(os.path.basename(img_path))[0]
        save_path = os.path.join(folder_path, img_name, name + ".gpkg")

        try:
            res = requests.get(TEMPLATE_URL, timeout=15)
            if res.status_code == 200:
                os.makedirs(os.path.join(folder_path, img_name), exist_ok=True)
                with open(save_path, 'wb') as f:
                    f.write(res.content)
                return [save_path]
            else:
                QMessageBox.warning(self.dlg, "Error", "ไม่สามารถเข้าถึงไฟล์ Template บน GitHub ได้")
        except Exception as e:
            QMessageBox.critical(self.dlg, "Error", f"ดาวน์โหลดล้มเหลว: {str(e)}")
            return None

    def process_load(self):
        # NEW FEATURE: ตรวจสอบงานค้างก่อนโหลดงานใหม่
        if not self._check_unsaved_changes():
            return

        root_path = self.dlg.line_path.text().strip()

        if not root_path or not os.path.exists(root_path):
            QMessageBox.critical(self.dlg, "ระงับการทำงาน", "กรุณาเลือกโฟลเดอร์หลักก่อน")
            return

        all_gpkgs = [
            os.path.join(r, f)
            for r, d, files in os.walk(root_path)
            for f in files if f.endswith('.gpkg')
        ]
        all_images = [
            os.path.join(root_path, f)
            for f in os.listdir(root_path) if f.endswith('.jpg')
        ]

        if not all_images:
            QMessageBox.critical(self.dlg, "ไม่พบไฟล์", "ต้องมีทั้งไฟล์รูปภาพ")
            return

        selected_img = all_images[0] if len(all_images) == 1 else None
        if len(all_images) > 1:
            img_dlg = FileSelectDialog(all_images, "เลือกรูปภาพ", "พบรูปภาพหลายไฟล์:", self.dlg)
            if img_dlg.exec_():
                selected_img = img_dlg.get_selected_file()
        if not selected_img:
            return

        img_name_no_ext = os.path.splitext(os.path.basename(selected_img))[0]
        filtered_gpkgs = [
            gpkg_path for gpkg_path in all_gpkgs
            if img_name_no_ext in os.path.basename(os.path.dirname(gpkg_path))
        ]
        all_gpkgs = filtered_gpkgs

        if not all_gpkgs:
            reply = QMessageBox.question(
                self.dlg, "ไม่พบข้อมูล",
                "ไม่พบไฟล์ Geopackage ที่ตรงกับชื่อรูปภาพที่เลือกในโฟลเดอร์นี้\nคุณต้องการดาวน์โหลด Template จาก GitHub หรือไม่?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.Yes:
                all_gpkgs = self.download_template_gpkg(root_path, selected_img)
            else:
                QMessageBox.critical(self.dlg, "ไม่พบไฟล์", "ต้องมีทั้งไฟล์ .gpkg และรูปภาพ")
                return

        # กัน crash: ดาวน์โหลด Template ล้มเหลวจะคืน None → len(None) จะ error
        if not all_gpkgs:
            return

        selected_gpkg = all_gpkgs[0] if len(all_gpkgs) == 1 else None
        if len(all_gpkgs) > 1:
            gpkg_dlg = FileSelectDialog(all_gpkgs, "เลือกไฟล์ GPKG", "พบไฟล์ GPKG หลายไฟล์:", self.dlg)
            if gpkg_dlg.exec_():
                selected_gpkg = gpkg_dlg.get_selected_file()
        if not selected_gpkg:
            return

        # BUG FIX #2: ลบ layer ผ่าน clear_previous_layers() ครั้งเดียว (ไม่ซ้ำซ้อน)
        self.clear_previous_layers()

        project = QgsProject.instance()
        root_node = project.layerTreeRoot()
        invalid_crs = QgsCoordinateReferenceSystem()
        project.setCrs(invalid_crs)

        # โหลด Raster
        rlayer = QgsRasterLayer(selected_img, f"[IMG] {os.path.basename(selected_img)}")
        if rlayer.isValid():
            project.addMapLayer(rlayer, False)
            root_node.insertLayer(-1, rlayer)
            self.loaded_layer_ids.append(rlayer.id())

        # โหลด Polygon
        self.poly_layer = QgsVectorLayer(f"{selected_gpkg}|layername=parcel_polygon", "parcel_polygon", "ogr")
        if self.poly_layer.isValid():
            self.poly_layer.setCrs(invalid_crs)
            symbol = QgsSymbol.defaultSymbol(self.poly_layer.geometryType())
            symbol.setColor(QColor(0, 0, 255))
            symbol_layer = symbol.symbolLayer(0)
            symbol_layer.setBrushStyle(Qt.NoBrush)
            symbol_layer.setStrokeColor(QColor(0, 0, 255))
            symbol_layer.setStrokeWidth(1)
            self.poly_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            project.addMapLayer(self.poly_layer, False)
            root_node.insertLayer(0, self.poly_layer)
            self.loaded_layer_ids.append(self.poly_layer.id())
            self.poly_layer.startEditing()

        # โหลด Point
        self.point_layer = QgsVectorLayer(f"{selected_gpkg}|layername=parcel_pcm", "parcel_pcm", "ogr")
        if self.point_layer.isValid():
            self.point_layer.setCrs(invalid_crs)
            p_symbol = QgsSymbol.defaultSymbol(self.point_layer.geometryType())
            p_symbol.setColor(QColor(255, 0, 0))
            p_symbol.setSize(3.0)
            self.point_layer.setRenderer(QgsSingleSymbolRenderer(p_symbol))

            label_settings = QgsPalLayerSettings()
            label_settings.fieldName = "pcmname"
            label_settings.enabled = True
            text_format = QgsTextFormat()
            text_format.setSize(12)
            text_format.setColor(QColor(255, 0, 0))
            text_format.buffer().setEnabled(True)
            text_format.buffer().setSize(1)
            label_settings.setFormat(text_format)
            self.point_layer.setLabeling(QgsVectorLayerSimpleLabeling(label_settings))
            self.point_layer.setLabelsEnabled(True)

            project.addMapLayer(self.point_layer, False)
            root_node.insertLayer(0, self.point_layer)
            self.loaded_layer_ids.append(self.point_layer.id())
            self.point_layer.startEditing()

        if self.poly_layer and self.poly_layer.isValid():
            project.setCrs(self.poly_layer.crs())

        # กันเคสไฟล์เสียหาย/เลือกไฟล์ผิด — layer ที่ invalid ยังเป็น truthy
        # ถ้าไม่เช็ค isValid() ปุ่มเครื่องมือจะถูกเปิดทั้งที่เลเยอร์ใช้งานไม่ได้
        missing = []
        if not (self.poly_layer and self.poly_layer.isValid()):
            missing.append("parcel_polygon")
        if not (self.point_layer and self.point_layer.isValid()):
            missing.append("parcel_pcm")
        if missing:
            self.clear_previous_layers()
            self.point_layer = None
            self.poly_layer = None
            QMessageBox.critical(
                self.dlg, "ไฟล์ GPKG ไม่สมบูรณ์",
                f"ไม่พบเลเยอร์ {', '.join(missing)} ในไฟล์:\n{selected_gpkg}\n\n"
                "ไฟล์อาจเสียหายหรือไม่ได้สร้างจาก Template ของระบบ")
            return

        if self.point_layer and self.poly_layer:
            self.current_root_path = root_path
            QSettings().setValue("GPKGEditor/lastFolder", root_path)
            self.dlg.update_display_path(root_path)
            self.setup_snapping([self.point_layer, self.poly_layer])
            self.dlg.btn_edit_point.setEnabled(True)
            self.dlg.btn_move_point.setEnabled(True)
            self.dlg.btn_save.setEnabled(True)
            self.dlg.btn_insert_point.setEnabled(True)
            self.dlg.btn_delete_point.setEnabled(True)
            self.iface.setActiveLayer(self.point_layer)
            self.iface.zoomToActiveLayer()
            self.dlg.btn_create_init.setEnabled(True)
            self.dlg.btn_delete_all.setEnabled(True)


# ---------------------------------------------------------------------------
# Tool: แก้ไขชื่อหมุด
# ---------------------------------------------------------------------------
class PointEditTool(QgsMapToolIdentifyFeature):
    def __init__(self, editor, iface, layer):
        self.editor = editor
        self.iface = iface
        self.canvas = iface.mapCanvas()
        super(PointEditTool, self).__init__(self.canvas, layer)
        self.layer = layer
        self.snap_indicator = QgsSnapIndicator(self.canvas)
        self.last_dialog_pos = None

    def canvasMoveEvent(self, event):
        snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        if snap_match.isValid():
            self.snap_indicator.setMatch(snap_match)
        else:
            self.snap_indicator.setMatch(QgsPointLocator.Match())

    def canvasReleaseEvent(self, event):
        snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        search_point = snap_match.point() if snap_match.isValid() else event.mapPoint()

        pixel_size = self.canvas.mapUnitsPerPixel()
        tolerance = pixel_size * CLICK_TOL_PX

        rect = QgsRectangle(
            search_point.x() - tolerance, search_point.y() - tolerance,
            search_point.x() + tolerance, search_point.y() + tolerance
        )

        request = QgsFeatureRequest().setFilterRect(rect).setLimit(1)
        features = list(self.layer.getFeatures(request))

        if features:
            self.edit_point_name(features[0])
        else:
            found = self.identify(event.x(), event.y(), [self.layer], self.IdentifyMode.TopDownAll)
            if found:
                self.edit_point_name(found[0].mFeature)

    def edit_point_name(self, feature):
        """แก้ไขชื่อหมุด พร้อมระบบจำตำแหน่งหน้าต่างล่าสุด"""
        old_name = str(feature['pcmname']) if feature['pcmname'] else ""

        accepted, new_name, self.last_dialog_pos = _prompt_point_name(
            self.iface.mainWindow(), "แก้ไขชื่อหมุด",
            f"ชื่อเดิม: {old_name}\n\nกรุณาใส่ชื่อใหม่ด้านล่าง:", old_name,
            self.last_dialog_pos)

        if accepted:
            if new_name and new_name != old_name:
                layer = self.layer
                idx = layer.fields().indexFromName('pcmname')
                if idx != -1:
                    if not layer.isEditable():
                        layer.startEditing()

                    self.editor._op_begin([layer])
                    layer.beginEditCommand(f"Rename Point: {old_name} -> {new_name}")
                    try:
                        layer.changeAttributeValue(feature.id(), idx, new_name)
                        layer.endEditCommand()
                        self.editor._op_commit()
                        layer.triggerRepaint()
                        self.iface.messageBar().pushMessage(
                            "สำเร็จ",
                            f"เปลี่ยนชื่อหมุดเป็น '{new_name}' เรียบร้อย",
                            level=0,
                            duration=3
                        )
                    except Exception as e:
                        layer.destroyEditCommand()
                        self.editor._op_commit()
                        self.iface.messageBar().pushMessage("Error", f"ไม่สามารถเปลี่ยนชื่อได้: {str(e)}", level=2)
                else:
                    self.iface.messageBar().pushMessage("Error", "ไม่พบฟิลด์ 'pcmname' ในเลเยอร์นี้", level=2)


# ---------------------------------------------------------------------------
# Tool: ลบหมุด
# ---------------------------------------------------------------------------
class PointDeleteTool(QgsMapTool):
    def __init__(self, editor, canvas, iface, point_layer, poly_layer):
        super().__init__(canvas)
        self.editor = editor
        self.canvas = canvas
        self.iface = iface
        self.point_layer = point_layer
        self.poly_layer = poly_layer
        self.setCursor(Qt.CrossCursor)

        self.snap_indicator = QgsSnapIndicator(self.canvas)
        self.is_drawing = False
        self.start_pos = None

        self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rubber_band.setColor(QColor(255, 0, 0, 40))
        self.rubber_band.setWidth(2)

    def canvasPressEvent(self, event):
        self.start_pos = event.mapPoint()
        self.is_drawing = True
        self.rubber_band.reset(QgsWkbTypes.PolygonGeometry)

    def canvasMoveEvent(self, event):
        match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        self.snap_indicator.setMatch(match)

        if self.is_drawing and self.start_pos:
            curr_pos = event.mapPoint()
            rect = QgsRectangle(self.start_pos, curr_pos)
            geom = QgsGeometry.fromRect(rect)
            self.rubber_band.setToGeometry(geom, None)
            self.rubber_band.show()

    def canvasReleaseEvent(self, event):
        self.is_drawing = False
        self.rubber_band.hide()

        if self.start_pos is None:
            return

        end_pos = event.mapPoint()
        rect = QgsRectangle(self.start_pos, end_pos)

        # เช็คทั้งกว้างและสูง — ลากกรอบแนวดิ่งล้วน (กว้าง~0) ต้องนับเป็นการลาก ไม่ใช่คลิกเดี่ยว
        if max(rect.width(), rect.height()) < self.canvas.mapUnitsPerPixel() * DRAG_MIN_PX:
            match = self.canvas.snappingUtils().snapToMap(end_pos)
            search_pt = match.point() if match.isValid() else end_pos
            tol = self.canvas.mapUnitsPerPixel() * CLICK_TOL_PX
            final_rect = QgsRectangle(
                search_pt.x() - tol, search_pt.y() - tol,
                search_pt.x() + tol, search_pt.y() + tol
            )
        else:
            final_rect = rect

        req = QgsFeatureRequest().setFilterRect(final_rect)
        found_features = list(self.point_layer.getFeatures(req))

        if found_features:
            self.process_deletion(found_features)

        self.rubber_band.reset(QgsWkbTypes.PolygonGeometry)

    def process_deletion(self, features):
        count = len(features)
        msg_text = f"ลบหมุดทั้งหมด {count} จุด?" if count > 1 else f"ลบหมุด {features[0]['pcmname']}?"

        res = QMessageBox.question(
            self.iface.mainWindow(), "ยืนยันการลบ",
            f"<b>{msg_text}</b>",
            QMessageBox.Yes | QMessageBox.No
        )
        if res == QMessageBox.Yes:
            self.execute_batch_delete(features)

    @staticmethod
    def _corner_count(vertices):
        """นับจำนวนมุมจริงของ ring (ตัดจุดปิดที่ซ้ำกับจุดแรกออก)"""
        n = len(vertices)
        if n >= 2 and vertices[0] == vertices[-1]:
            n -= 1
        return n

    @staticmethod
    def _feature_parts(geom):
        """คืนโครงสร้าง [part][ring][pt] — รองรับทั้ง Polygon เดี่ยวและ MultiPolygon
        (แปลงหลายก้อนต้องประมวลผลราย ring ไม่งั้น vertex ทุกก้อนจะถูกยุบรวมเป็นก้อนเดียว)"""
        if geom.isMultipart():
            return geom.asMultiPolygon()
        poly = geom.asPolygon()
        return [poly] if poly else []

    def execute_batch_delete(self, features):
        # จับคู่หมุดกับ vertex ของ polygon ด้วย tolerance (พิกัด float เทียบตรงตัวไม่ได้)
        tol = self.canvas.mapUnitsPerPixel() * NODE_TOL_PX
        pts = [{'feat': f, 'xy': QgsPointXY(f.geometry().asPoint())} for f in features]

        xs = [p['xy'].x() for p in pts]
        ys = [p['xy'].y() for p in pts]
        search_rect = QgsRectangle(min(xs) - tol, min(ys) - tol, max(xs) + tol, max(ys) + tol)
        polys = list(self.poly_layer.getFeatures(QgsFeatureRequest().setFilterRect(search_rect)))

        # ── Pass 1: หาหมุดที่ "ห้ามลบ" — คิดเป็นราย ring (รองรับแปลงหลายก้อน) ──
        # ring ที่เหลือ 1-2 มุม (รูปไม่ปิด) ห้ามลบ / ring ที่หมุดหายทั้งก้อน
        # ยอมให้ลบได้ถ้าแปลงยังเหลือก้อนอื่นที่สมบูรณ์
        blocked_xy = []
        for poly_feat in polys:
            ring_stats = []
            for part in self._feature_parts(poly_feat.geometry()):
                for ring in part:
                    kept, matched = [], []
                    for v in ring:
                        hit = next((p for p in pts if v.compare(p['xy'], tol)), None)
                        if hit is None:
                            kept.append(v)
                        else:
                            matched.append(hit)
                    ring_stats.append((matched, self._corner_count(kept)))
            live_rings = sum(1 for _m, k in ring_stats if k >= 3)
            for matched, k in ring_stats:
                if not matched or k >= 3:
                    continue
                if k == 0 and live_rings >= 1:
                    continue    # ก้อนนี้ถูกลบทั้งก้อน แต่แปลงยังเหลือก้อนอื่น -> อนุญาต
                blocked_xy.extend(p['xy'] for p in matched)

        def is_blocked(p):
            return any(p['xy'].compare(b, tol) for b in blocked_xy)

        deletable = [p for p in pts if not is_blocked(p)]
        blocked = [p for p in pts if is_blocked(p)]

        # ไม่มีหมุดที่ลบได้เลย -> เก็บไว้ทั้งหมด + เตือน
        if not deletable:
            QMessageBox.warning(
                self.iface.mainWindow(), "ลบหมุดไม่ได้",
                "ลบหมุดนี้ไม่ได้ เพราะรูปแปลงจะเหลือน้อยกว่า 3 มุม (ไม่เป็นรูปปิด)\n\n"
                "หมุดถูกเก็บไว้ตามเดิม — ถ้าต้องการล้างทั้งแปลง ใช้ปุ่ม 🧹 ลบรูปแปลงและหมุดทั้งหมด")
            return

        # ── Pass 2: คำนวณ geometry ใหม่เป็นราย ring — ก้อนที่หมุดหมดถูกตัดออกจากแปลง ──
        del_xy = [p['xy'] for p in deletable]
        poly_updates = []
        for poly_feat in polys:
            changed = False
            new_parts = []
            for part in self._feature_parts(poly_feat.geometry()):
                new_rings = []
                for ring in part:
                    kept = [v for v in ring if not any(v.compare(d, tol) for d in del_xy)]
                    if len(kept) < len(ring):
                        changed = True
                    if self._corner_count(kept) >= 3:
                        if kept[0] != kept[-1]:
                            kept.append(kept[0])
                        new_rings.append(kept)
                if new_rings:
                    new_parts.append(new_rings)
            if not (changed and new_parts):
                continue
            if QgsWkbTypes.isMultiType(self.poly_layer.wkbType()) or len(new_parts) > 1:
                new_geom = QgsGeometry.fromMultiPolygonXY(new_parts)
            else:
                new_geom = QgsGeometry.fromPolygonXY(new_parts[0])
            if not new_geom.isNull():
                poly_updates.append((poly_feat.id(), new_geom))

        # ── ลงมือแก้ไข ──
        if not self.point_layer.isEditable():
            self.point_layer.startEditing()
        if not self.poly_layer.isEditable():
            self.poly_layer.startEditing()

        self.editor._op_begin([self.point_layer, self.poly_layer])
        self.point_layer.beginEditCommand(f"Batch Delete {len(deletable)} Points")
        self.poly_layer.beginEditCommand("Sync Polygon Nodes")
        try:
            self.point_layer.deleteFeatures([p['feat'].id() for p in deletable])
            for poly_id, new_geom in poly_updates:
                self.poly_layer.changeGeometry(poly_id, new_geom)

            self.point_layer.endEditCommand()
            self.poly_layer.endEditCommand()
            self.editor._op_commit()

            self.point_layer.triggerRepaint()
            self.poly_layer.triggerRepaint()
            self.canvas.refresh()

            if blocked:
                QMessageBox.warning(
                    self.iface.mainWindow(), "ลบบางหมุดไม่ได้",
                    f"ลบ {len(deletable)} จุดเรียบร้อย\n\n"
                    f"⚠️ อีก {len(blocked)} จุดถูกเก็บไว้ เพราะถ้าลบแล้วรูปแปลงจะเหลือน้อยกว่า 3 มุม")
            else:
                self.iface.messageBar().pushMessage("สำเร็จ", f"ลบ {len(deletable)} จุดเรียบร้อย", level=0, duration=2)

        except Exception as e:
            self.point_layer.destroyEditCommand()
            self.poly_layer.destroyEditCommand()
            self.editor._op_commit()
            self.iface.messageBar().pushMessage("Error", f"พบข้อผิดพลาด: {str(e)}", level=2)

    def deactivate(self):
        self.snap_indicator.setMatch(QgsPointLocator.Match())
        self.rubber_band.reset()
        super().deactivate()


# ---------------------------------------------------------------------------
# Tool: ย้ายหมุด
# ---------------------------------------------------------------------------
class PointMoveTool(QgsMapToolEmitPoint):
    def __init__(self, editor, iface, point_layer, poly_layer):
        super(PointMoveTool, self).__init__(iface.mapCanvas())
        self.editor = editor
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.point_layer = point_layer
        self.poly_layer = poly_layer
        self.is_dragging = False
        self.target_feat_id = None
        self.poly_nodes = []
        self.drag_geoms = {}   # fid -> {'geom': geometry ต้นฉบับตอนกดเมาส์, 'idxs': [vertex index]}

        self.snap_indicator = QgsSnapIndicator(self.canvas)

        self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rubber_band.setColor(QColor(0, 255, 0, 100))
        self.rubber_band.setWidth(2)

    def canvasMoveEvent(self, event):
        snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        if snap_match.isValid():
            self.snap_indicator.setMatch(snap_match)
        else:
            self.snap_indicator.setMatch(QgsPointLocator.Match())

        if self.is_dragging:
            curr_pt = event.mapPoint()
            self.rubber_band.reset(QgsWkbTypes.PolygonGeometry)
            # ใช้ geometry ที่ cache ไว้ตอนกดเมาส์ — ไม่ดึงจาก provider (ไฟล์บนแชร์)
            # ซ้ำทุก mouse move และแสดง preview ครบทุกแปลงที่ใช้หมุดร่วมกัน
            for info in self.drag_geoms.values():
                tmp_geom = QgsGeometry(info['geom'])
                for idx in info['idxs']:
                    tmp_geom.moveVertex(curr_pt.x(), curr_pt.y(), idx)
                self.rubber_band.addGeometry(tmp_geom, self.poly_layer)

    def canvasPressEvent(self, event):
        self.is_dragging = False
        self.target_feat_id = None
        self.poly_nodes = []
        self.drag_geoms = {}

        snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        search_point = snap_match.point() if snap_match.isValid() else event.mapPoint()

        tolerance = self.canvas.mapUnitsPerPixel() * CLICK_TOL_PX
        rect = QgsRectangle(
            search_point.x() - tolerance, search_point.y() - tolerance,
            search_point.x() + tolerance, search_point.y() + tolerance
        )

        request = QgsFeatureRequest().setFilterRect(rect).setLimit(1)
        point_features = list(self.point_layer.getFeatures(request))

        if point_features:
            self.is_dragging = True
            target_feat = point_features[0]
            self.target_feat_id = target_feat.id()
            start_point = target_feat.geometry().asPoint()

            # PERF #5: ใช้ spatial filter บน poly_layer ก่อน loop vertex
            # แทนการ loop ผ่าน polygon ทุกตัวและ vertex ทุกจุด
            poly_tolerance = self.canvas.mapUnitsPerPixel() * NODE_TOL_PX
            poly_search_rect = QgsRectangle(
                start_point.x() - poly_tolerance, start_point.y() - poly_tolerance,
                start_point.x() + poly_tolerance, start_point.y() + poly_tolerance
            )
            poly_req = QgsFeatureRequest().setFilterRect(poly_search_rect)
            for feat in self.poly_layer.getFeatures(poly_req):
                geom = feat.geometry()
                matched_idxs = []
                for i, pt in enumerate(geom.vertices()):
                    if QgsPointXY(pt).compare(QgsPointXY(start_point), poly_tolerance):
                        self.poly_nodes.append({'fid': feat.id(), 'node_idx': i})
                        matched_idxs.append(i)
                if matched_idxs:
                    self.drag_geoms[feat.id()] = {'geom': QgsGeometry(geom), 'idxs': matched_idxs}
        else:
            self.iface.messageBar().pushMessage("แจ้งเตือน", "ไม่พบหมุดแดงในรัศมีที่คลิก", level=1, duration=2)

    def canvasReleaseEvent(self, event):
        if not self.is_dragging or self.target_feat_id is None:
            return

        end_pt = event.mapPoint()

        if not self.point_layer.isEditable():
            self.point_layer.startEditing()
        if not self.poly_layer.isEditable():
            self.poly_layer.startEditing()

        cmd_name = f"Move Point {self.target_feat_id}"
        self.editor._op_begin([self.point_layer, self.poly_layer])
        self.point_layer.beginEditCommand(cmd_name)
        self.poly_layer.beginEditCommand(cmd_name)

        success = False
        try:
            self.point_layer.moveVertex(end_pt.x(), end_pt.y(), self.target_feat_id, 0)
            for node in self.poly_nodes:
                self.poly_layer.moveVertex(end_pt.x(), end_pt.y(), node['fid'], node['node_idx'])
            success = True
        except Exception as e:
            print(f"Error during move: {e}")

        self.point_layer.endEditCommand()
        self.poly_layer.endEditCommand()
        self.editor._op_commit()

        if success:
            self.point_layer.triggerRepaint()
            self.poly_layer.triggerRepaint()
            self.iface.messageBar().pushMessage("สำเร็จ", "ย้ายหมุดเรียบร้อย", level=0, duration=2)

        self.rubber_band.reset()
        self.is_dragging = False

    def deactivate(self):
        self.snap_indicator.setMatch(QgsPointLocator.Match())
        self.rubber_band.reset()
        self.is_dragging = False
        self.drag_geoms = {}
        super(PointMoveTool, self).deactivate()


# ---------------------------------------------------------------------------
# Tool: แทรกหมุด
# ---------------------------------------------------------------------------
class PointInsertTool(QgsMapToolEmitPoint):
    def __init__(self, editor, iface, point_layer, poly_layer):
        super(PointInsertTool, self).__init__(iface.mapCanvas())
        self.editor = editor
        self.iface, self.canvas = iface, iface.mapCanvas()
        self.point_layer, self.poly_layer = point_layer, poly_layer
        self.snap_indicator = QgsSnapIndicator(self.canvas)
        self.selected_points = []
        self.rb_pts = QgsRubberBand(self.canvas, QgsWkbTypes.PointGeometry)
        self.rb_pts.setColor(QColor(255, 255, 0, 200))
        self.rb_line = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rb_line.setColor(QColor(255, 165, 0, 200))
        self.rb_line.setWidth(2)
        self.last_dialog_pos = None

    def canvasMoveEvent(self, event):
        if len(self.selected_points) < 2:
            snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
            self.snap_indicator.setMatch(snap_match if snap_match.isValid() else QgsPointLocator.Match())
        else:
            self.snap_indicator.setMatch(QgsPointLocator.Match())

        if len(self.selected_points) == 2:
            self.rb_line.reset(QgsWkbTypes.LineGeometry)
            self.rb_line.addPoint(self.selected_points[0]['point'])
            self.rb_line.addPoint(event.mapPoint())
            self.rb_line.addPoint(self.selected_points[1]['point'])

    def canvasReleaseEvent(self, event):
        if len(self.selected_points) < 2:
            snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
            search_pt = snap_match.point() if snap_match.isValid() else event.mapPoint()

            tol = self.canvas.mapUnitsPerPixel() * CLICK_TOL_PX
            rect = QgsRectangle(
                search_pt.x() - tol, search_pt.y() - tol,
                search_pt.x() + tol, search_pt.y() + tol
            )

            req = QgsFeatureRequest().setFilterRect(rect).setLimit(1)
            found_features = list(self.point_layer.getFeatures(req))

            if found_features:
                actual_pt = found_features[0].geometry().asPoint()
                self.selected_points.append({'point': actual_pt})
                self.rb_pts.addPoint(actual_pt)

                msg = "เลือกหมุดที่ 2" if len(self.selected_points) == 1 else "คลิกจุดเพื่อวางหมุดใหม่ (ปิดระบบ Snap ชั่วคราว)"
                self.iface.messageBar().pushMessage("ระบบ", msg, level=0, duration=2)
            else:
                self.iface.messageBar().pushMessage("แจ้งเตือน", "กรุณาคลิกให้โดนหมุดแดง", level=1, duration=2)
            return

        new_pt = event.mapPoint()
        self.execute_insert(new_pt)
        self.reset_tool()

    def execute_insert(self, new_pt):
        if len(self.selected_points) < 2:
            return

        p1 = QgsPointXY(self.selected_points[0]['point'])
        p2 = QgsPointXY(self.selected_points[1]['point'])

        target_poly = None
        insert_idx = -1
        tol = self.canvas.mapUnitsPerPixel() * CLICK_TOL_PX

        # PERF #6: ใช้ spatial filter หา polygon เฉพาะที่อยู่รอบ segment p1-p2
        min_x = min(p1.x(), p2.x()) - tol
        min_y = min(p1.y(), p2.y()) - tol
        max_x = max(p1.x(), p2.x()) + tol
        max_y = max(p1.y(), p2.y()) + tol
        search_rect = QgsRectangle(min_x, min_y, max_x, max_y)
        poly_req = QgsFeatureRequest().setFilterRect(search_rect)

        for feat in self.poly_layer.getFeatures(poly_req):
            geom = feat.geometry()
            nodes = list(geom.vertices())
            num_nodes = len(nodes)

            for i in range(num_nodes):
                curr_v = QgsPointXY(nodes[i])
                next_v = QgsPointXY(nodes[(i + 1) % num_nodes])

                is_segment_match = (
                    (curr_v.compare(p1, tol) and next_v.compare(p2, tol)) or
                    (curr_v.compare(p2, tol) and next_v.compare(p1, tol))
                )

                if is_segment_match:
                    target_poly = feat
                    insert_idx = (i + 1) % num_nodes
                    if i == num_nodes - 1:
                        insert_idx = num_nodes
                    break

            if target_poly:
                break

        if target_poly and insert_idx != -1:
            self.editor._op_begin([self.point_layer, self.poly_layer])
            self.point_layer.beginEditCommand("Insert Point")
            self.poly_layer.beginEditCommand("Insert Point")

            new_f = QgsFeature(self.point_layer.fields())
            new_f.setGeometry(QgsGeometry.fromPointXY(new_pt))
            name_idx = self.point_layer.fields().indexFromName('pcmname')
            if name_idx != -1:
                new_f.setAttribute(name_idx, "NEW_PCM")

            self.point_layer.addFeature(new_f)
            new_fid = new_f.id()

            success_poly = self.poly_layer.insertVertex(new_pt.x(), new_pt.y(), target_poly.id(), insert_idx)

            if success_poly:
                accepted, new_name, self.last_dialog_pos = _prompt_point_name(
                    self.iface.mainWindow(), "ตั้งชื่อหมุดใหม่",
                    "✨ เพิ่มตำแหน่งหมุดใหม่เรียบร้อย!\nกรุณาใส่ชื่อหมุดที่ต้องการ:", "NEW_PCM",
                    self.last_dialog_pos, accent="#4caf50", label_color="#2e7d32")

                if accepted and new_name and name_idx != -1:
                    self.point_layer.changeAttributeValue(new_fid, name_idx, new_name)

                self.point_layer.endEditCommand()
                self.poly_layer.endEditCommand()
                self.editor._op_commit()
                self.point_layer.triggerRepaint()
                self.poly_layer.triggerRepaint()
                self.iface.messageBar().pushMessage("สำเร็จ", "แทรกหมุดเรียบร้อย", level=0, duration=2)
            else:
                self.point_layer.destroyEditCommand()
                self.poly_layer.destroyEditCommand()
                self.editor._op_commit()
        else:
            self.iface.messageBar().pushMessage("แจ้งเตือน", "ไม่พบเส้นขอบที่เชื่อมระหว่างหมุดที่เลือก", level=1, duration=3)

    def reset_tool(self):
        self.selected_points = []
        self.rb_pts.reset()
        self.rb_line.reset()

    def deactivate(self):
        self.snap_indicator.setMatch(QgsPointLocator.Match())
        self.reset_tool()
        super(PointInsertTool, self).deactivate()


# ---------------------------------------------------------------------------
# Tool: วาดรูปแปลงและหมุดใหม่
# ---------------------------------------------------------------------------
class InitialDrawTool(QgsMapToolEmitPoint):
    def __init__(self, editor, iface, point_layer, poly_layer):
        super(InitialDrawTool, self).__init__(iface.mapCanvas())
        self.editor = editor
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.point_layer = point_layer
        self.poly_layer = poly_layer
        self.points = []      # จุดของก้อนที่กำลังวาดอยู่
        self.parts = []       # ก้อนที่ปิดไปแล้ว (โฉนดแปลงเดียวที่มีหลายก้อนแยกกัน)
        self.is_drawing = False

        self.rb_line = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rb_line.setColor(QColor(255, 165, 0, 150))
        self.rb_line.setWidth(2)

        self.rb_poly = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb_poly.setColor(QColor(0, 0, 255, 40))
        self.rb_poly.setStrokeColor(QColor(0, 0, 255, 200))

        # แสดงก้อนที่ปิดแล้วค้างไว้บนจอระหว่างวาดก้อนถัดไป
        self.rb_done = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb_done.setColor(QColor(0, 0, 255, 40))
        self.rb_done.setStrokeColor(QColor(0, 0, 255, 200))

    def canvasMoveEvent(self, event):
        curr_pt = event.mapPoint()

        if len(self.points) == 1:
            self.rb_line.reset(QgsWkbTypes.LineGeometry)
            self.rb_line.addPoint(self.points[0])
            self.rb_line.addPoint(curr_pt)

        elif len(self.points) >= 2:
            snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
            final_pt = snap_match.point() if snap_match.isValid() else curr_pt

            self.rb_poly.reset(QgsWkbTypes.PolygonGeometry)
            for p in self.points:
                self.rb_poly.addPoint(p)
            self.rb_poly.addPoint(final_pt)

    def canvasReleaseEvent(self, event):
        if event.button() == Qt.RightButton:
            # Shift+คลิกขวา = ปิดก้อนนี้แล้ววาดก้อนถัดไป (โฉนดที่มีหลายก้อนแยกกัน)
            # คลิกขวาเปล่า = จบแปลง (รวมทุกก้อนเป็นโฉนดเดียวกัน)
            if event.modifiers() & Qt.ShiftModifier:
                self.close_current_part()
            else:
                self.finalize_geometry()
            return

        if event.button() == Qt.LeftButton:
            snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
            click_pt = snap_match.point() if snap_match.isValid() else event.mapPoint()

            if not self.is_drawing:
                self.editor._op_begin([self.point_layer, self.poly_layer])
                self.point_layer.beginEditCommand("Create Plot and Points")
                self.poly_layer.beginEditCommand("Create Plot and Points")
                self.is_drawing = True

            if len(self.points) > 2 and snap_match.isValid():
                if snap_match.point().compare(self.points[0], self.canvas.mapUnitsPerPixel() * CLICK_TOL_PX):
                    self.finalize_geometry()
                    return

            self.points.append(click_pt)
            # นับเลขหมุดต่อเนื่องข้ามก้อน — กันชื่อ PCM ซ้ำเมื่อโฉนดมีหลายก้อน
            total = sum(len(p) for p in self.parts) + len(self.points)
            self.create_instant_point(click_pt, total)

    def create_instant_point(self, pt, count):
        """สร้างหมุด PCM"""
        if not self.point_layer.isEditable():
            self.point_layer.startEditing()

        feat = QgsFeature(self.point_layer.fields())
        feat.setGeometry(QgsGeometry.fromPointXY(pt))
        idx = self.point_layer.fields().indexFromName('pcmname')
        if idx != -1:
            feat.setAttribute(idx, f"PCM_{count}")
        self.point_layer.addFeature(feat)
        self.point_layer.triggerRepaint()

    def close_current_part(self):
        """ปิดก้อนปัจจุบันเก็บไว้ แล้วเริ่มวาดก้อนถัดไป (โฉนดแปลงเดียวที่มีหลายก้อน)"""
        if len(self.points) < 3:
            self.iface.messageBar().pushMessage(
                "แจ้งเตือน", "ต้องวางหมุดอย่างน้อย 3 จุดก่อนปิดก้อน", level=1, duration=2)
            return
        ring = [QgsPointXY(p.x(), p.y()) for p in self.points]
        self.parts.append(ring)
        self.rb_done.addGeometry(QgsGeometry.fromPolygonXY([ring]), None)
        self.points = []
        self.rb_line.reset(QgsWkbTypes.LineGeometry)
        self.rb_poly.reset(QgsWkbTypes.PolygonGeometry)
        self.iface.messageBar().pushMessage(
            "ระบบ", f"ปิดก้อนที่ {len(self.parts)} แล้ว — วาดก้อนถัดไปได้เลย (คลิกขวาเมื่อจบแปลง)",
            level=0, duration=3)

    def finalize_geometry(self):
        """สร้างรูปแปลงจากทุกก้อนที่วาด แล้วจบ Command ทั้งหมด"""
        rings = [list(part) for part in self.parts]
        if len(self.points) >= 3:
            rings.append([QgsPointXY(p.x(), p.y()) for p in self.points])
        elif self.points:
            self.iface.messageBar().pushMessage(
                "แจ้งเตือน", "ก้อนปัจจุบันมีไม่ถึง 3 จุด — วางหมุดเพิ่ม หรือกด Reset เพื่อยกเลิก",
                level=1, duration=3)
            return
        if not rings:
            self.iface.messageBar().pushMessage(
                "แจ้งเตือน", "ยังไม่ได้วางหมุด — คลิกซ้ายเพื่อเริ่มวาด", level=1, duration=2)
            return

        if not self.poly_layer.isEditable():
            self.poly_layer.startEditing()

        for ring in rings:
            if ring[0] != ring[-1]:
                ring.append(ring[0])

        # ไฟล์จาก Template ประกาศชนิด Polygon เดี่ยว — commit MultiPolygon ลงไปไม่ผ่าน
        # ('geometry type is not compatible') จึงบันทึกก้อนละ 1 feature โดยใช้
        # landno/utmmap ชุดเดียวกัน (เติมอัตโนมัติตอนบันทึก) = โฉนดแปลงเดียวกัน
        # ถ้าเลเยอร์เป็นชนิด Multi อยู่แล้วจะรวมทุกก้อนเป็น feature เดียว
        if QgsWkbTypes.isMultiType(self.poly_layer.wkbType()):
            poly_feat = QgsFeature(self.poly_layer.fields())
            poly_feat.setGeometry(QgsGeometry.fromMultiPolygonXY([[r] for r in rings]))
            self.poly_layer.addFeature(poly_feat)
        else:
            for ring in rings:
                poly_feat = QgsFeature(self.poly_layer.fields())
                poly_feat.setGeometry(QgsGeometry.fromPolygonXY([ring]))
                self.poly_layer.addFeature(poly_feat)

        self.point_layer.endEditCommand()
        self.poly_layer.endEditCommand()
        self.editor._op_commit()

        self.point_layer.triggerRepaint()
        self.poly_layer.triggerRepaint()
        self.is_drawing = False

        if len(rings) > 1:
            self.iface.messageBar().pushMessage(
                "สำเร็จ", f"สร้างรูปแปลงที่ดิน {len(rings)} ก้อนเรียบร้อย", level=0)
        else:
            self.iface.messageBar().pushMessage("สำเร็จ", "สร้างรูปแปลงที่ดินเรียบร้อย", level=0)
        self.reset_tool()
        self.canvas.unsetMapTool(self)
        self.iface.actionPan().trigger()

    def reset_tool(self):
        if self.is_drawing:
            self.point_layer.destroyEditCommand()
            self.poly_layer.destroyEditCommand()
            self.editor._op_commit()
            self.is_drawing = False
            self.point_layer.triggerRepaint()
            self.poly_layer.triggerRepaint()

        self.points = []
        self.parts = []
        self.rb_line.reset()
        self.rb_poly.reset()
        self.rb_done.reset()

    def deactivate(self):
        self.reset_tool()
        super(InitialDrawTool, self).deactivate()
