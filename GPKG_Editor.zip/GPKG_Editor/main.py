import requests
import zipfile
import io
import os
from qgis.PyQt.QtCore import Qt, QSettings, QTimer, QRect
from qgis.PyQt.QtWidgets import (QAction, QFileDialog, QMessageBox, QDialog,
                                QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton,
                                QLabel, QListWidget, QAbstractItemView, QInputDialog, QFrame,
                                QProgressDialog)
from qgis.core import (QgsProject, QgsVectorLayer, QgsRasterLayer, QgsRectangle,
                       QgsGeometry, QgsPointXY, QgsFeatureRequest, QgsPoint,
                       QgsSymbol, QgsSingleSymbolRenderer, QgsPalLayerSettings,
                       QgsTextFormat, QgsVectorLayerSimpleLabeling,
                       QgsSnappingConfig, QgsTolerance, QgsPointLocator, QgsWkbTypes, QgsFeature,
                       QgsCoordinateReferenceSystem, QgsSpatialIndex)
from qgis.gui import (QgsMapToolIdentifyFeature, QgsMapTool, QgsMapToolExtent,
                      QgsSnapIndicator,
                      QgsMapCanvas,
                      QgsMapToolEmitPoint,
                      QgsRubberBand)
from qgis.PyQt.QtGui import QColor, QIcon


class GPKGEditorDialog(QDialog):
    def __init__(self, parent=None):
        super(GPKGEditorDialog, self).__init__(parent)
        self.version = "1.0.7"
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.setWindowIcon(QIcon(icon_path))
        self.setWindowTitle(f"GPKG Editor {self.version}")
        self.setMinimumWidth(400)
        layout = QVBoxLayout(self)

        # --- โซนที่ 1: การสแกนและโหลดข้อมูล ---
        layout.addWidget(QLabel("<b>📁 โซนสแกนและโหลดข้อมูล</b>"))
        path_layout = QHBoxLayout()
        self.line_path = QLineEdit()
        self.btn_browse = QPushButton("เลือก Folder...")
        self.btn_browse.clicked.connect(self.browse_folder)
        path_layout.addWidget(self.line_path)
        path_layout.addWidget(self.btn_browse)
        layout.addLayout(path_layout)

        self.btn_load = QPushButton("🚀 สแกนและโหลดข้อมูล")
        self.btn_load.setStyleSheet("font-weight: bold; height: 35px; background-color: #e1f5fe;")
        layout.addWidget(self.btn_load)

        # เส้นแบ่งโซน
        line1 = QFrame()
        line1.setFrameShape(QFrame.HLine)
        line1.setFrameShadow(QFrame.Sunken)
        layout.addWidget(line1)
        layout.addSpacing(5)

        self.UTMMAP = QLabel("<i>ยังไม่ได้สแกนและโหลดข้อมูล</i>")
        self.UTMMAP.setStyleSheet("font-weight: bold; padding: 5px; background-color: #f0f4c3; ")
        info_font = self.UTMMAP.font()
        info_font.setPointSize(16)
        self.UTMMAP.setFont(info_font)
        self.UTMMAP.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.UTMMAP)

        # เส้นแบ่งโซน
        layout.addSpacing(5)
        line1_ = QFrame()
        line1_.setFrameShape(QFrame.HLine)
        line1_.setFrameShadow(QFrame.Sunken)
        layout.addWidget(line1_)
        layout.addSpacing(5)

        self.btn_create_init = QPushButton("🆕 สร้างรูปแปลงและหมุดใหม่")
        self.btn_create_init.setStyleSheet("font-weight: bold; height: 35px; ")
        self.btn_create_init.setEnabled(False)
        layout.addWidget(self.btn_create_init)

        layout.addSpacing(5)
        line1_1 = QFrame()
        line1_1.setFrameShape(QFrame.HLine)
        line1_1.setFrameShadow(QFrame.Sunken)
        layout.addWidget(line1_1)
        layout.addSpacing(5)

        # --- โซนที่ 2: เครื่องมือจัดการหมุด (จัดกลุ่มซ้าย-ขวา) ---
        layout.addWidget(QLabel("<b>🛠️ เครื่องมือจัดการหมุด</b>"))

        # บรรทัด: ย้ายหมุด (ซ้าย) | แทรกหมุด (ขวา)
        row1_layout = QHBoxLayout()
        self.btn_move_point = QPushButton("📍 ย้ายหมุด")
        self.btn_move_point.setStyleSheet("font-weight: bold; height: 35px; ")
        self.btn_move_point.setEnabled(False)

        self.btn_insert_point = QPushButton("➕ แทรกหมุด")
        self.btn_insert_point.setStyleSheet("font-weight: bold; height: 35px; ")
        self.btn_insert_point.setEnabled(False)

        row1_layout.addWidget(self.btn_move_point)
        row1_layout.addWidget(self.btn_insert_point)
        layout.addLayout(row1_layout)

        # บรรทัด: แก้ไขชื่อหมุด (ซ้าย) | ลบหมุด (ขวา)
        row2_layout = QHBoxLayout()
        self.btn_edit_point = QPushButton("✏️ แก้ไขชื่อหมุด")
        self.btn_edit_point.setStyleSheet("font-weight: bold; height: 35px;")
        self.btn_edit_point.setEnabled(False)

        self.btn_delete_point = QPushButton("🗑️ ลบหมุด")
        self.btn_delete_point.setStyleSheet("font-weight: bold; height: 35px; ")
        self.btn_delete_point.setEnabled(False)

        row2_layout.addWidget(self.btn_edit_point)
        row2_layout.addWidget(self.btn_delete_point)
        layout.addLayout(row2_layout)

        # เส้นแบ่งโซน
        layout.addSpacing(5)
        line2 = QFrame()
        line2.setFrameShape(QFrame.HLine)
        line2.setFrameShadow(QFrame.Sunken)
        layout.addWidget(line2)
        layout.addSpacing(5)

        # --- โซนที่ 3: ระบบควบคุมและย้อนกลับ ---
        row3_layout = QHBoxLayout()
        self.btn_reset = QPushButton("🔄 Reset / Cancel")
        self.btn_reset.setStyleSheet("font-weight: bold; height: 30px; background-color: #f5f5f5;")

        self.btn_undo = QPushButton("↩️ Undo (ย้อนกลับ)")
        self.btn_undo.setStyleSheet("font-weight: bold; height: 30px; background-color: #ffebee; color: #c62828;")

        row3_layout.addWidget(self.btn_reset)
        row3_layout.addWidget(self.btn_undo)
        layout.addLayout(row3_layout)

        self.btn_save = QPushButton("💾 บันทึกการแก้ไขทั้งหมด (Save)")
        self.btn_save.setStyleSheet("height: 45px; font-weight: bold; background-color: #c8e6c9; color: #2e7d32; font-size: 14px;")
        self.btn_save.setEnabled(False)
        layout.addWidget(self.btn_save)

        layout.addSpacing(5)
        line3 = QFrame()
        line3.setFrameShape(QFrame.HLine)
        line3.setFrameShadow(QFrame.Sunken)
        layout.addWidget(line3)
        layout.addSpacing(5)

        self.btn_upd = QPushButton("🚀 Check Update")
        self.btn_upd.setStyleSheet("height: 30px; background-color: #f3e5f5;")
        layout.addWidget(self.btn_upd)

        lbl_author = QLabel("จัดทำโดย: ชาคฤตย์ จันทรสุกศรี")
        lbl_dept = QLabel("กองเทคโนโลยีทำแผนที่ กรมที่ดิน")

        info_font = lbl_author.font()
        info_font.setPointSize(9)
        lbl_author.setFont(info_font)
        lbl_dept.setFont(info_font)
        lbl_author.setAlignment(Qt.AlignCenter)
        lbl_dept.setAlignment(Qt.AlignCenter)

        layout.addWidget(lbl_author)
        layout.addWidget(lbl_dept)

    def update_display_path(self, full_path):
        name = _build_name_from_path(full_path)
        self.UTMMAP.setText(name if name else "---")

    def browse_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "เลือกโฟลเดอร์")
        if folder:
            self.line_path.setText(folder)


class FileSelectDialog(QDialog):
    def __init__(self, file_list, title, label_text, parent=None):
        super(FileSelectDialog, self).__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(550)
        layout = QVBoxLayout(self)
        self.list_widget = QListWidget()
        for path in file_list:
            self.list_widget.addItem(path)
        self.list_widget.setSelectionMode(QAbstractItemView.SingleSelection)
        layout.addWidget(QLabel(f"<b>{label_text}</b>"))
        layout.addWidget(self.list_widget)
        btn_ok = QPushButton("ตกลง")
        btn_ok.clicked.connect(self.accept)
        layout.addWidget(btn_ok)

    def get_selected_file(self):
        selected = self.list_widget.selectedItems()
        return selected[0].text() if selected else None


# ---------------------------------------------------------------------------
# Helper function (module-level) — สร้างชื่อจาก path
# แก้ปัญหา: logic ซ้ำกันระหว่าง update_display_path() และ download_template_gpkg()
# ---------------------------------------------------------------------------
def _build_name_from_path(folder_path):
    """
    แปลง path โฟลเดอร์ให้เป็นชื่องาน เช่น 'A B C-D(SCALE)_LANDNO'
    คืนค่าสตริงชื่อ หรือ None ถ้า path ไม่ครบ
    """
    parts = os.path.normpath(folder_path).split(os.sep)
    if len(parts) > 5:
        UTMMAP1  = parts[-6]
        UTMMAP2  = parts[-5]
        UTMMAP3  = parts[-4]
        UTMSCALE = parts[-3]
        UTMMAP4  = parts[-2]
        LANDNO   = parts[-1]
        return f"{UTMMAP1} {UTMMAP2} {UTMMAP3}-{UTMMAP4}({UTMSCALE})_{LANDNO}"
    return None


class GPKGEditor:
    def __init__(self, iface):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        self.dlg = GPKGEditorDialog(self.iface.mainWindow())
        self.loaded_layer_ids = []
        self.point_layer = None
        self.poly_layer = None
        self.edit_tool = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.action = QAction(QIcon(icon_path), "เปิด GPKG Editor", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        # BUG FIX #1: ลบการลงทะเบียนซ้ำ — เรียกแค่ครั้งเดียว
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&GPKG Editor", self.action)

        self.dlg.btn_upd.clicked.connect(self.update_plugin)
        self.dlg.btn_load.clicked.connect(self.process_load)
        self.dlg.btn_edit_point.clicked.connect(self.activate_edit_tool)
        self.dlg.btn_move_point.clicked.connect(self.activate_move_tool)
        self.dlg.btn_reset.clicked.connect(self.reset_to_select)
        self.dlg.btn_undo.clicked.connect(self.undo_action)
        self.dlg.btn_save.clicked.connect(self.save_changes)
        self.dlg.btn_insert_point.clicked.connect(self.activate_insert_tool)
        self.dlg.btn_delete_point.clicked.connect(self.activate_delete_tool)
        self.dlg.btn_create_init.clicked.connect(self.activate_initial_draw_tool)

    # -----------------------------------------------------------------------
    # NEW FEATURE: ตรวจสอบงานที่ยังไม่บันทึกก่อนโหลดงานใหม่
    # -----------------------------------------------------------------------
    def _check_unsaved_changes(self):
        """
        ตรวจสอบว่า layer ที่โหลดอยู่มีการแก้ไขที่ยังไม่บันทึกหรือไม่

        Returns:
            True  — ดำเนินการต่อได้ (ไม่มีงานค้าง, บันทึกแล้ว, หรือ Discard)
            False — ผู้ใช้กด Cancel → ยกเลิกการโหลดงานใหม่
        """
        layers_to_check = [
            layer for layer in [self.point_layer, self.poly_layer]
            if layer and layer.isEditable() and layer.isModified()
        ]

        if not layers_to_check:
            return True  # ไม่มีงานค้าง → ดำเนินการต่อได้เลย

        layer_names = ", ".join(l.name() for l in layers_to_check)
        reply = QMessageBox.question(
            self.dlg,
            "⚠️ มีงานที่ยังไม่ได้บันทึก",
            f"พบการแก้ไขที่ยังไม่ได้บันทึกใน:\n  • {layer_names}\n\n"
            f"ต้องการบันทึกก่อนโหลดงานใหม่หรือไม่?",
            QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel,
            QMessageBox.Save  # default button
        )

        if reply == QMessageBox.Save:
            self.save_changes()
            return True
        elif reply == QMessageBox.Discard:
            # ผู้ใช้เลือกทิ้งการแก้ไข → rollback ก่อนดำเนินการต่อ
            for layer in layers_to_check:
                layer.rollBack()
            return True
        else:
            # ผู้ใช้กด Cancel → หยุดการโหลด
            return False

    def update_plugin(self):
        V_URL = "https://raw.githubusercontent.com/chakrit39/GPKG_Editor/refs/heads/main/version.txt"
        Z_URL = "https://github.com/chakrit39/GPKG_Editor/raw/refs/heads/main/GPKG_Editor.zip"

        try:
            # 1. ตรวจสอบเวอร์ชัน
            res = requests.get(V_URL, timeout=5)
            remote_version = res.text.strip()

            if remote_version > self.dlg.version:
                reply = QMessageBox.question(
                    self.dlg, "พบเวอร์ชันใหม่",
                    f"เวอร์ชันใหม่ ({remote_version}) พร้อมใช้งาน\nคุณต้องการอัปเดตทันทีหรือไม่?",
                    QMessageBox.Yes | QMessageBox.No
                )

                if reply == QMessageBox.Yes:
                    # PERF: เพิ่ม Progress Dialog ขณะดาวน์โหลด (stream=True)
                    progress = QProgressDialog("กำลังดาวน์โหลด...", "ยกเลิก", 0, 0, self.dlg)
                    progress.setWindowTitle("อัปเดตปลั๊กอิน")
                    progress.setWindowModality(Qt.WindowModal)
                    progress.show()

                    r = requests.get(Z_URL, timeout=60, stream=True)
                    chunks = []
                    for chunk in r.iter_content(chunk_size=8192):
                        if progress.wasCanceled():
                            progress.close()
                            return
                        if chunk:
                            chunks.append(chunk)
                    progress.close()

                    z = zipfile.ZipFile(io.BytesIO(b"".join(chunks)))
                    plugin_dir = os.path.dirname(os.path.dirname(__file__))
                    z.extractall(plugin_dir)

                    QMessageBox.information(self.dlg, "อัปเดตสำเร็จ",
                                            "อัปเดตปลั๊กอินเรียบร้อยแล้ว!\nกรุณา Restart QGIS เพื่อเริ่มใช้งานเวอร์ชันใหม่")
            else:
                QMessageBox.information(self.dlg, "อัปเดต", "คุณกำลังใช้งานเวอร์ชันล่าสุดแล้ว")

        except Exception as e:
            QMessageBox.warning(self.dlg, "เกิดข้อผิดพลาด", f"ไม่สามารถตรวจสอบการอัปเดตได้:\n{str(e)}")

    def activate_delete_tool(self):
        if not self.point_layer or not self.poly_layer:
            return
        self.delete_tool = PointDeleteTool(self.canvas, self.iface, self.point_layer, self.poly_layer)
        self.canvas.setMapTool(self.delete_tool)

    def activate_insert_tool(self):
        if self.point_layer and self.poly_layer:
            self.insert_tool = PointInsertTool(self.iface, self.point_layer, self.poly_layer)
            self.canvas.setMapTool(self.insert_tool)

    def save_changes(self):
        """บันทึกการแก้ไขลงไฟล์ GPKG และหยุดโหมดการแก้ไข"""
        layers_to_save = [self.point_layer, self.poly_layer]
        success_count = 0

        for layer in layers_to_save:
            if layer and layer.isEditable():
                if layer.commitChanges():
                    success_count += 1
                else:
                    self.iface.messageBar().pushMessage(
                        "Error",
                        f"ไม่สามารถบันทึกเลเยอร์ {layer.name()} ได้: {layer.commitErrors()}",
                        level=2
                    )
                    layer.rollBack()

        if success_count > 0:
            self.iface.messageBar().pushMessage("สำเร็จ", "บันทึกข้อมูลลง Geopackage เรียบร้อยแล้ว", level=0, duration=3)
            # เปิดโหมดแก้ไขต่อเพื่อทำงานต่อได้ทันที
            self.point_layer.startEditing()
            self.poly_layer.startEditing()

    def undo_action(self):
        """ย้อนกลับการกระทำล่าสุดในเลเยอร์ที่กำลังแก้ไข"""
        if self.point_layer and self.point_layer.isEditable():
            self.point_layer.undoStack().undo()
            self.point_layer.triggerRepaint()

        if self.poly_layer and self.poly_layer.isEditable():
            self.poly_layer.undoStack().undo()
            self.poly_layer.triggerRepaint()

        self.iface.messageBar().pushMessage("Undo", "ย้อนกลับการแก้ไขล่าสุดแล้ว", level=0, duration=2)

    def reset_to_select(self):
        """คืนค่าเครื่องมือกลับไปเป็นลูกศรเลือก (Select) มาตรฐานของ QGIS"""
        # BUG FIX #3: ป้องกัน crash เมื่อ tool ยังไม่ถูก activate
        for tool_attr in ('edit_tool', 'move_tool', 'delete_tool', 'insert_tool', 'init_draw_tool'):
            tool = getattr(self, tool_attr, None)
            if tool is not None:
                self.canvas.unsetMapTool(tool)

        self.iface.actionPan().trigger()
        self.iface.messageBar().pushMessage("ระบบ", "คืนค่าเป็นเครื่องมือปกติแล้ว", level=0, duration=2)

    def activate_move_tool(self):
        if self.point_layer and self.poly_layer:
            self.move_tool = PointMoveTool(self.iface, self.point_layer, self.poly_layer)
            self.canvas.setMapTool(self.move_tool)
            self.iface.messageBar().pushMessage("ระบบ", "คลิกค้างที่จุดแล้วลากเพื่อย้ายตำแหน่ง", level=0, duration=3)

    def unload(self):
        self.iface.removePluginMenu("&GPKG Editor", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        self.dlg.show()

    def clear_previous_layers(self):
        if self.loaded_layer_ids:
            QgsProject.instance().removeMapLayers(self.loaded_layer_ids)
            self.loaded_layer_ids = []
            self.point_layer = None
            self.poly_layer = None

    def setup_snapping(self, layers):
        config = QgsProject.instance().snappingConfig()
        config.setEnabled(True)
        config.setMode(QgsSnappingConfig.AdvancedConfiguration)
        config.clearIndividualLayerSettings()

        for lyr in layers:
            if lyr:
                setting = QgsSnappingConfig.IndividualLayerSettings()
                setting.setEnabled(True)
                setting.type = QgsSnappingConfig.Vertex | QgsSnappingConfig.Segment
                setting.setTolerance(20)
                setting.setUnits(QgsTolerance.Pixels)
                config.setIndividualLayerSettings(lyr, setting)

        QgsProject.instance().setSnappingConfig(config)

    def activate_edit_tool(self):
        if self.point_layer:
            self.edit_tool = PointEditTool(self.iface, self.point_layer)
            self.canvas.setMapTool(self.edit_tool)

    def activate_initial_draw_tool(self):
        # ตรวจสอบว่าเลเยอร์ว่างจริงไหม
        point_count = self.point_layer.featureCount()
        poly_count = self.poly_layer.featureCount()

        if point_count > 0 or poly_count > 0:
            QMessageBox.warning(
                self.dlg,
                "ไม่อนุญาต",
                f"เครื่องมือนี้ใช้สำหรับสร้างข้อมูลใหม่เท่านั้น\nขณะนี้พบ Point: {point_count} และ Polygon: {poly_count} features"
            )
            return

        self.init_draw_tool = InitialDrawTool(self.iface, self.point_layer, self.poly_layer)
        self.canvas.setMapTool(self.init_draw_tool)

        self.iface.messageBar().pushMessage(
            "วิธีใช้งาน",
            "คลิกซ้ายเพื่อวางจุด, คลิกขวาเมื่อวาดเสร็จเพื่อสร้างแปลง",
            level=0,
            duration=5
        )

    def download_template_gpkg(self, folder_path, img_path):
        """ดึงไฟล์ Template จาก GitHub มาวางในโฟลเดอร์ที่เลือก"""
        TEMPLATE_URL = "https://github.com/chakrit39/GPKG_Editor/raw/refs/heads/main/template.gpkg"

        # CODE QUALITY #7: ใช้ helper function แทน logic ซ้ำ
        name = _build_name_from_path(folder_path) or "Error_Path"
        img_name = "_" + os.path.splitext(os.path.basename(img_path))[0]
        save_path = os.path.join(folder_path, img_name, name + ".gpkg")

        try:
            res = requests.get(TEMPLATE_URL, timeout=15)
            if res.status_code == 200:
                os.makedirs(os.path.join(folder_path, img_name), exist_ok=True)
                with open(save_path, 'wb') as f:
                    f.write(res.content)
                return [save_path]
            else:
                QMessageBox.warning(self.dlg, "Error", "ไม่สามารถเข้าถึงไฟล์ Template บน GitHub ได้")
        except Exception as e:
            QMessageBox.critical(self.dlg, "Error", f"ดาวน์โหลดล้มเหลว: {str(e)}")
            return None

    def process_load(self):
        # NEW FEATURE: ตรวจสอบงานค้างก่อนโหลดงานใหม่
        if not self._check_unsaved_changes():
            return

        root_path = self.dlg.line_path.text().strip()

        if not root_path or not os.path.exists(root_path):
            QMessageBox.critical(self.dlg, "ระงับการทำงาน", "กรุณาเลือกโฟลเดอร์หลักก่อน")
            return

        all_gpkgs = [
            os.path.join(r, f)
            for r, d, files in os.walk(root_path)
            for f in files if f.endswith('.gpkg')
        ]
        all_images = [
            os.path.join(root_path, f)
            for f in os.listdir(root_path) if f.endswith('.jpg')
        ]

        if not all_images:
            QMessageBox.critical(self.dlg, "ไม่พบไฟล์", "ต้องมีทั้งไฟล์รูปภาพ")
            return

        selected_img = all_images[0] if len(all_images) == 1 else None
        if len(all_images) > 1:
            img_dlg = FileSelectDialog(all_images, "เลือกรูปภาพ", "พบรูปภาพหลายไฟล์:", self.dlg)
            if img_dlg.exec_():
                selected_img = img_dlg.get_selected_file()
        if not selected_img:
            return

        img_name_no_ext = os.path.splitext(os.path.basename(selected_img))[0]
        filtered_gpkgs = [
            gpkg_path for gpkg_path in all_gpkgs
            if img_name_no_ext in os.path.basename(os.path.dirname(gpkg_path))
        ]
        all_gpkgs = filtered_gpkgs

        if not all_gpkgs:
            reply = QMessageBox.question(
                self.dlg, "ไม่พบข้อมูล",
                "ไม่พบไฟล์ Geopackage ที่ตรงกับชื่อรูปภาพที่เลือกในโฟลเดอร์นี้\nคุณต้องการดาวน์โหลด Template จาก GitHub หรือไม่?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.Yes:
                all_gpkgs = self.download_template_gpkg(root_path, selected_img)
            else:
                QMessageBox.critical(self.dlg, "ไม่พบไฟล์", "ต้องมีทั้งไฟล์ .gpkg และรูปภาพ")
                return

        selected_gpkg = all_gpkgs[0] if len(all_gpkgs) == 1 else None
        if len(all_gpkgs) > 1:
            gpkg_dlg = FileSelectDialog(all_gpkgs, "เลือกไฟล์ GPKG", "พบไฟล์ GPKG หลายไฟล์:", self.dlg)
            if gpkg_dlg.exec_():
                selected_gpkg = gpkg_dlg.get_selected_file()
        if not selected_gpkg:
            return

        # BUG FIX #2: ลบ layer ผ่าน clear_previous_layers() ครั้งเดียว (ไม่ซ้ำซ้อน)
        self.clear_previous_layers()

        project = QgsProject.instance()
        root_node = project.layerTreeRoot()
        invalid_crs = QgsCoordinateReferenceSystem()
        project.setCrs(invalid_crs)

        # โหลด Raster
        rlayer = QgsRasterLayer(selected_img, f"[IMG] {os.path.basename(selected_img)}")
        if rlayer.isValid():
            project.addMapLayer(rlayer, False)
            root_node.insertLayer(-1, rlayer)
            self.loaded_layer_ids.append(rlayer.id())

        # โหลด Polygon
        self.poly_layer = QgsVectorLayer(f"{selected_gpkg}|layername=parcel_polygon", "parcel_polygon", "ogr")
        if self.poly_layer.isValid():
            self.poly_layer.setCrs(invalid_crs)
            symbol = QgsSymbol.defaultSymbol(self.poly_layer.geometryType())
            symbol.setColor(QColor(0, 0, 255))
            symbol_layer = symbol.symbolLayer(0)
            symbol_layer.setBrushStyle(Qt.NoBrush)
            symbol_layer.setStrokeColor(QColor(0, 0, 255))
            symbol_layer.setStrokeWidth(1)
            self.poly_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            project.addMapLayer(self.poly_layer, False)
            root_node.insertLayer(0, self.poly_layer)
            self.loaded_layer_ids.append(self.poly_layer.id())
            self.poly_layer.startEditing()

        # โหลด Point
        self.point_layer = QgsVectorLayer(f"{selected_gpkg}|layername=parcel_pcm", "parcel_pcm", "ogr")
        if self.point_layer.isValid():
            self.point_layer.setCrs(invalid_crs)
            p_symbol = QgsSymbol.defaultSymbol(self.point_layer.geometryType())
            p_symbol.setColor(QColor(255, 0, 0))
            p_symbol.setSize(3.0)
            self.point_layer.setRenderer(QgsSingleSymbolRenderer(p_symbol))

            label_settings = QgsPalLayerSettings()
            label_settings.fieldName = "pcmname"
            label_settings.enabled = True
            text_format = QgsTextFormat()
            text_format.setSize(12)
            text_format.setColor(QColor(255, 0, 0))
            text_format.buffer().setEnabled(True)
            text_format.buffer().setSize(1)
            label_settings.setFormat(text_format)
            self.point_layer.setLabeling(QgsVectorLayerSimpleLabeling(label_settings))
            self.point_layer.setLabelsEnabled(True)

            project.addMapLayer(self.point_layer, False)
            root_node.insertLayer(0, self.point_layer)
            self.loaded_layer_ids.append(self.point_layer.id())
            self.point_layer.startEditing()

        if self.poly_layer and self.poly_layer.isValid():
            project.setCrs(self.poly_layer.crs())

        if self.point_layer and self.poly_layer:
            self.dlg.update_display_path(root_path)
            self.setup_snapping([self.point_layer, self.poly_layer])
            self.dlg.btn_edit_point.setEnabled(True)
            self.dlg.btn_move_point.setEnabled(True)
            self.dlg.btn_save.setEnabled(True)
            self.dlg.btn_insert_point.setEnabled(True)
            self.dlg.btn_delete_point.setEnabled(True)
            self.iface.setActiveLayer(self.point_layer)
            self.iface.zoomToActiveLayer()
            self.dlg.btn_create_init.setEnabled(True)


# ---------------------------------------------------------------------------
# Tool: แก้ไขชื่อหมุด
# ---------------------------------------------------------------------------
class PointEditTool(QgsMapToolIdentifyFeature):
    def __init__(self, iface, layer):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        super(PointEditTool, self).__init__(self.canvas, layer)
        self.layer = layer
        self.snap_indicator = QgsSnapIndicator(self.canvas)
        self.last_dialog_pos = None

    def canvasMoveEvent(self, event):
        snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        if snap_match.isValid():
            self.snap_indicator.setMatch(snap_match)
        else:
            self.snap_indicator.setMatch(QgsPointLocator.Match())

    def canvasReleaseEvent(self, event):
        snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        search_point = snap_match.point() if snap_match.isValid() else event.mapPoint()

        pixel_size = self.canvas.mapUnitsPerPixel()
        tolerance = pixel_size * 10

        rect = QgsRectangle(
            search_point.x() - tolerance, search_point.y() - tolerance,
            search_point.x() + tolerance, search_point.y() + tolerance
        )

        request = QgsFeatureRequest().setFilterRect(rect).setLimit(1)
        features = list(self.layer.getFeatures(request))

        if features:
            self.edit_point_name(features[0])
        else:
            found = self.identify(event.x(), event.y(), [self.layer], self.IdentifyMode.TopDownAll)
            if found:
                self.edit_point_name(found[0].mFeature)

    def edit_point_name(self, feature):
        """แก้ไขชื่อหมุด พร้อมระบบจำตำแหน่งหน้าต่างล่าสุด"""
        old_name = str(feature['pcmname']) if feature['pcmname'] else ""

        dialog = QInputDialog(self.iface.mainWindow())
        dialog.setWindowTitle("แก้ไขชื่อหมุด")
        dialog.setLabelText(f"ชื่อเดิม: {old_name}\n\nกรุณาใส่ชื่อใหม่ด้านล่าง:")
        dialog.setTextValue(old_name)

        if self.last_dialog_pos:
            dialog.move(self.last_dialog_pos)

        dialog.resize(300, 350)
        dialog.setStyleSheet("""
            QLabel {
                font-size: 16px;
                font-weight: bold;
                color: #2c3e50;
                margin-bottom: 5px;
            }
            QLineEdit {
                font-size: 20px;
                padding: 10px;
                border: 2px solid #3498db;
                border-radius: 6px;
                background-color: #ffffff;
            }
            QPushButton {
                font-size: 15px;
                min-width: 100px;
                min-height: 35px;
                background-color: #f8f9fa;
                border: 1px solid #ced4da;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #e2e6ea;
            }
        """)

        result = dialog.exec_()
        self.last_dialog_pos = dialog.pos()

        if result:
            new_name = dialog.textValue()
            if new_name and new_name != old_name:
                layer = self.layer
                idx = layer.fields().indexFromName('pcmname')
                if idx != -1:
                    if not layer.isEditable():
                        layer.startEditing()

                    layer.beginEditCommand(f"Rename Point: {old_name} -> {new_name}")
                    try:
                        layer.changeAttributeValue(feature.id(), idx, new_name)
                        layer.endEditCommand()
                        layer.triggerRepaint()
                        self.iface.messageBar().pushMessage(
                            "สำเร็จ",
                            f"เปลี่ยนชื่อหมุดเป็น '{new_name}' เรียบร้อย",
                            level=0,
                            duration=3
                        )
                    except Exception as e:
                        layer.destroyEditCommand()
                        self.iface.messageBar().pushMessage("Error", f"ไม่สามารถเปลี่ยนชื่อได้: {str(e)}", level=2)
                else:
                    self.iface.messageBar().pushMessage("Error", "ไม่พบฟิลด์ 'pcmname' ในเลเยอร์นี้", level=2)


# ---------------------------------------------------------------------------
# Tool: ลบหมุด
# ---------------------------------------------------------------------------
class PointDeleteTool(QgsMapTool):
    def __init__(self, canvas, iface, point_layer, poly_layer):
        super().__init__(canvas)
        self.canvas = canvas
        self.iface = iface
        self.point_layer = point_layer
        self.poly_layer = poly_layer
        self.setCursor(Qt.CrossCursor)

        self.snap_indicator = QgsSnapIndicator(self.canvas)
        self.is_drawing = False
        self.start_pos = None

        self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rubber_band.setColor(QColor(255, 0, 0, 40))
        self.rubber_band.setWidth(2)

    def canvasPressEvent(self, event):
        self.start_pos = event.mapPoint()
        self.is_drawing = True
        self.rubber_band.reset(QgsWkbTypes.PolygonGeometry)

    def canvasMoveEvent(self, event):
        match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        self.snap_indicator.setMatch(match)

        if self.is_drawing and self.start_pos:
            curr_pos = event.mapPoint()
            rect = QgsRectangle(self.start_pos, curr_pos)
            geom = QgsGeometry.fromRect(rect)
            self.rubber_band.setToGeometry(geom, None)
            self.rubber_band.show()

    def canvasReleaseEvent(self, event):
        self.is_drawing = False
        self.rubber_band.hide()

        end_pos = event.mapPoint()
        rect = QgsRectangle(self.start_pos, end_pos)

        if rect.width() < self.canvas.mapUnitsPerPixel() * 2:
            match = self.canvas.snappingUtils().snapToMap(end_pos)
            search_pt = match.point() if match.isValid() else end_pos
            tol = self.canvas.mapUnitsPerPixel() * 10
            final_rect = QgsRectangle(
                search_pt.x() - tol, search_pt.y() - tol,
                search_pt.x() + tol, search_pt.y() + tol
            )
        else:
            final_rect = rect

        req = QgsFeatureRequest().setFilterRect(final_rect)
        found_features = list(self.point_layer.getFeatures(req))

        if found_features:
            self.process_deletion(found_features)

        self.rubber_band.reset(QgsWkbTypes.PolygonGeometry)

    def process_deletion(self, features):
        count = len(features)
        msg_text = f"ลบหมุดทั้งหมด {count} จุด?" if count > 1 else f"ลบหมุด {features[0]['pcmname']}?"

        res = QMessageBox.question(
            self.iface.mainWindow(), "ยืนยันการลบ",
            f"<b>{msg_text}</b>",
            QMessageBox.Yes | QMessageBox.No
        )
        if res == QMessageBox.Yes:
            self.execute_batch_delete(features)

    def execute_batch_delete(self, features):
        if not self.point_layer.isEditable():
            self.point_layer.startEditing()
        if not self.poly_layer.isEditable():
            self.poly_layer.startEditing()

        self.point_layer.beginEditCommand(f"Batch Delete {len(features)} Points")
        self.poly_layer.beginEditCommand("Sync Polygon Nodes")

        try:
            ids_to_delete = [f.id() for f in features]

            # PERF #4: แปลง points_to_remove เป็น set ของ tuple พิกัด
            # เพื่อใช้ lookup O(1) แทน nested loop O(n)
            tol = self.canvas.mapUnitsPerPixel() * 5
            points_to_remove = [QgsPointXY(f.geometry().asPoint()) for f in features]

            # สร้าง bounding box รวมของจุดทั้งหมดที่จะลบ เพื่อ filter polygon
            min_x = min(p.x() for p in points_to_remove) - tol
            min_y = min(p.y() for p in points_to_remove) - tol
            max_x = max(p.x() for p in points_to_remove) + tol
            max_y = max(p.y() for p in points_to_remove) + tol
            search_rect = QgsRectangle(min_x, min_y, max_x, max_y)

            # 1. ลบหมุดออกจากเลเยอร์ Point
            self.point_layer.deleteFeatures(ids_to_delete)

            # 2. PERF: ใช้ spatial filter เพื่อ loop เฉพาะ polygon ที่เกี่ยวข้อง
            poly_req = QgsFeatureRequest().setFilterRect(search_rect)
            for poly_feat in self.poly_layer.getFeatures(poly_req):
                geom = poly_feat.geometry()
                all_vertices = [QgsPointXY(v) for v in geom.vertices()]
                new_vertices = []

                for v_xy in all_vertices:
                    # ใช้ any() + generator แทน nested loop ซ้อน 3 ชั้น
                    should_remove = any(v_xy.compare(p_del, tol) for p_del in points_to_remove)
                    if not should_remove:
                        new_vertices.append(v_xy)

                if len(new_vertices) < len(all_vertices) and len(new_vertices) >= 3:
                    new_geom = QgsGeometry.fromPolygonXY([new_vertices])
                    if not new_geom.isNull():
                        self.poly_layer.changeGeometry(poly_feat.id(), new_geom)

            self.point_layer.endEditCommand()
            self.poly_layer.endEditCommand()

            self.point_layer.triggerRepaint()
            self.poly_layer.triggerRepaint()
            self.canvas.refresh()

            self.iface.messageBar().pushMessage("สำเร็จ", f"ลบ {len(features)} จุดเรียบร้อย", level=0, duration=2)

        except Exception as e:
            self.point_layer.destroyEditCommand()
            self.poly_layer.destroyEditCommand()
            self.iface.messageBar().pushMessage("Error", f"พบข้อผิดพลาด: {str(e)}", level=2)

    def deactivate(self):
        self.snap_indicator.setMatch(QgsPointLocator.Match())
        self.rubber_band.reset()
        super().deactivate()


# ---------------------------------------------------------------------------
# Tool: ย้ายหมุด
# ---------------------------------------------------------------------------
class PointMoveTool(QgsMapToolEmitPoint):
    def __init__(self, iface, point_layer, poly_layer):
        super(PointMoveTool, self).__init__(iface.mapCanvas())
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.point_layer = point_layer
        self.poly_layer = poly_layer
        self.is_dragging = False
        self.target_feat_id = None
        self.poly_nodes = []

        self.snap_indicator = QgsSnapIndicator(self.canvas)

        self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rubber_band.setColor(QColor(0, 255, 0, 100))
        self.rubber_band.setWidth(2)

    def canvasMoveEvent(self, event):
        snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        if snap_match.isValid():
            self.snap_indicator.setMatch(snap_match)
        else:
            self.snap_indicator.setMatch(QgsPointLocator.Match())

        if self.is_dragging:
            curr_pt = event.mapPoint()
            self.rubber_band.reset(QgsWkbTypes.PolygonGeometry)
            if self.poly_nodes:
                node_info = self.poly_nodes[0]
                feat = self.poly_layer.getFeature(node_info['fid'])
                tmp_geom = QgsGeometry(feat.geometry())
                tmp_geom.moveVertex(curr_pt.x(), curr_pt.y(), node_info['node_idx'])
                self.rubber_band.setToGeometry(tmp_geom, self.poly_layer)

    def canvasPressEvent(self, event):
        self.is_dragging = False
        self.target_feat_id = None
        self.poly_nodes = []

        snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        search_point = snap_match.point() if snap_match.isValid() else event.mapPoint()

        tolerance = self.canvas.mapUnitsPerPixel() * 10
        rect = QgsRectangle(
            search_point.x() - tolerance, search_point.y() - tolerance,
            search_point.x() + tolerance, search_point.y() + tolerance
        )

        request = QgsFeatureRequest().setFilterRect(rect).setLimit(1)
        point_features = list(self.point_layer.getFeatures(request))

        if point_features:
            self.is_dragging = True
            target_feat = point_features[0]
            self.target_feat_id = target_feat.id()
            start_point = target_feat.geometry().asPoint()

            # PERF #5: ใช้ spatial filter บน poly_layer ก่อน loop vertex
            # แทนการ loop ผ่าน polygon ทุกตัวและ vertex ทุกจุด
            poly_tolerance = self.canvas.mapUnitsPerPixel() * 5
            poly_search_rect = QgsRectangle(
                start_point.x() - poly_tolerance, start_point.y() - poly_tolerance,
                start_point.x() + poly_tolerance, start_point.y() + poly_tolerance
            )
            poly_req = QgsFeatureRequest().setFilterRect(poly_search_rect)
            for feat in self.poly_layer.getFeatures(poly_req):
                geom = feat.geometry()
                for i, pt in enumerate(geom.vertices()):
                    if QgsPointXY(pt).compare(QgsPointXY(start_point), poly_tolerance):
                        self.poly_nodes.append({'fid': feat.id(), 'node_idx': i})
        else:
            self.iface.messageBar().pushMessage("แจ้งเตือน", "ไม่พบหมุดแดงในรัศมีที่คลิก", level=1, duration=2)

    def canvasReleaseEvent(self, event):
        if not self.is_dragging or self.target_feat_id is None:
            return

        end_pt = event.mapPoint()

        if not self.point_layer.isEditable():
            self.point_layer.startEditing()
        if not self.poly_layer.isEditable():
            self.poly_layer.startEditing()

        cmd_name = f"Move Point {self.target_feat_id}"
        self.point_layer.beginEditCommand(cmd_name)
        self.poly_layer.beginEditCommand(cmd_name)

        success = False
        try:
            self.point_layer.moveVertex(end_pt.x(), end_pt.y(), self.target_feat_id, 0)
            for node in self.poly_nodes:
                self.poly_layer.moveVertex(end_pt.x(), end_pt.y(), node['fid'], node['node_idx'])
            success = True
        except Exception as e:
            print(f"Error during move: {e}")

        self.point_layer.endEditCommand()
        self.poly_layer.endEditCommand()

        if success:
            self.point_layer.triggerRepaint()
            self.poly_layer.triggerRepaint()
            self.iface.messageBar().pushMessage("สำเร็จ", "ย้ายหมุดเรียบร้อย", level=0, duration=2)

        self.rubber_band.reset()
        self.is_dragging = False

    def deactivate(self):
        self.snap_indicator.setMatch(QgsPointLocator.Match())
        self.rubber_band.reset()
        self.is_dragging = False
        super(PointMoveTool, self).deactivate()


# ---------------------------------------------------------------------------
# Tool: แทรกหมุด
# ---------------------------------------------------------------------------
class PointInsertTool(QgsMapToolEmitPoint):
    def __init__(self, iface, point_layer, poly_layer):
        super(PointInsertTool, self).__init__(iface.mapCanvas())
        self.iface, self.canvas = iface, iface.mapCanvas()
        self.point_layer, self.poly_layer = point_layer, poly_layer
        self.snap_indicator = QgsSnapIndicator(self.canvas)
        self.selected_points = []
        self.rb_pts = QgsRubberBand(self.canvas, QgsWkbTypes.PointGeometry)
        self.rb_pts.setColor(QColor(255, 255, 0, 200))
        self.rb_line = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rb_line.setColor(QColor(255, 165, 0, 200))
        self.rb_line.setWidth(2)
        self.last_dialog_pos = None

    def canvasMoveEvent(self, event):
        if len(self.selected_points) < 2:
            snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
            self.snap_indicator.setMatch(snap_match if snap_match.isValid() else QgsPointLocator.Match())
        else:
            self.snap_indicator.setMatch(QgsPointLocator.Match())

        if len(self.selected_points) == 2:
            self.rb_line.reset(QgsWkbTypes.LineGeometry)
            self.rb_line.addPoint(self.selected_points[0]['point'])
            self.rb_line.addPoint(event.mapPoint())
            self.rb_line.addPoint(self.selected_points[1]['point'])

    def canvasReleaseEvent(self, event):
        if len(self.selected_points) < 2:
            snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
            search_pt = snap_match.point() if snap_match.isValid() else event.mapPoint()

            tol = self.canvas.mapUnitsPerPixel() * 10
            rect = QgsRectangle(
                search_pt.x() - tol, search_pt.y() - tol,
                search_pt.x() + tol, search_pt.y() + tol
            )

            req = QgsFeatureRequest().setFilterRect(rect).setLimit(1)
            found_features = list(self.point_layer.getFeatures(req))

            if found_features:
                actual_pt = found_features[0].geometry().asPoint()
                self.selected_points.append({'point': actual_pt})
                self.rb_pts.addPoint(actual_pt)

                msg = "เลือกหมุดที่ 2" if len(self.selected_points) == 1 else "คลิกจุดเพื่อวางหมุดใหม่ (ปิดระบบ Snap ชั่วคราว)"
                self.iface.messageBar().pushMessage("ระบบ", msg, level=0, duration=2)
            else:
                self.iface.messageBar().pushMessage("แจ้งเตือน", "กรุณาคลิกให้โดนหมุดแดง", level=1, duration=2)
            return

        new_pt = event.mapPoint()
        self.execute_insert(new_pt)
        self.reset_tool()

    def execute_insert(self, new_pt):
        if len(self.selected_points) < 2:
            return

        p1 = QgsPointXY(self.selected_points[0]['point'])
        p2 = QgsPointXY(self.selected_points[1]['point'])

        target_poly = None
        insert_idx = -1
        tol = self.canvas.mapUnitsPerPixel() * 10

        # PERF #6: ใช้ spatial filter หา polygon เฉพาะที่อยู่รอบ segment p1-p2
        min_x = min(p1.x(), p2.x()) - tol
        min_y = min(p1.y(), p2.y()) - tol
        max_x = max(p1.x(), p2.x()) + tol
        max_y = max(p1.y(), p2.y()) + tol
        search_rect = QgsRectangle(min_x, min_y, max_x, max_y)
        poly_req = QgsFeatureRequest().setFilterRect(search_rect)

        for feat in self.poly_layer.getFeatures(poly_req):
            geom = feat.geometry()
            nodes = list(geom.vertices())
            num_nodes = len(nodes)

            for i in range(num_nodes):
                curr_v = QgsPointXY(nodes[i])
                next_v = QgsPointXY(nodes[(i + 1) % num_nodes])

                is_segment_match = (
                    (curr_v.compare(p1, tol) and next_v.compare(p2, tol)) or
                    (curr_v.compare(p2, tol) and next_v.compare(p1, tol))
                )

                if is_segment_match:
                    target_poly = feat
                    insert_idx = (i + 1) % num_nodes
                    if i == num_nodes - 1:
                        insert_idx = num_nodes
                    break

            if target_poly:
                break

        if target_poly and insert_idx != -1:
            self.point_layer.beginEditCommand("Insert Point")
            self.poly_layer.beginEditCommand("Insert Point")

            new_f = QgsFeature(self.point_layer.fields())
            new_f.setGeometry(QgsGeometry.fromPointXY(new_pt))
            name_idx = self.point_layer.fields().indexFromName('pcmname')
            if name_idx != -1:
                new_f.setAttribute(name_idx, "NEW_PCM")

            self.point_layer.addFeature(new_f)
            new_fid = new_f.id()

            success_poly = self.poly_layer.insertVertex(new_pt.x(), new_pt.y(), target_poly.id(), insert_idx)

            if success_poly:
                dialog = QInputDialog(self.iface.mainWindow())
                dialog.setWindowTitle("ตั้งชื่อหมุดใหม่")
                dialog.setLabelText("✨ เพิ่มตำแหน่งหมุดใหม่เรียบร้อย!\nกรุณาใส่ชื่อหมุดที่ต้องการ:")
                dialog.setTextValue("NEW_PCM")

                if self.last_dialog_pos:
                    dialog.move(self.last_dialog_pos)

                dialog.resize(300, 350)
                dialog.setStyleSheet("""
                    QLabel { font-size: 16px; font-weight: bold; color: #2e7d32; margin-bottom: 5px; }
                    QLineEdit { font-size: 20px; padding: 10px; border: 2px solid #4caf50; border-radius: 6px; }
                    QPushButton { font-size: 15px; min-width: 100px; min-height: 35px; }
                """)

                result = dialog.exec_()
                self.last_dialog_pos = dialog.pos()

                if result:
                    new_name = dialog.textValue()
                    if new_name and name_idx != -1:
                        self.point_layer.changeAttributeValue(new_fid, name_idx, new_name)

                self.point_layer.endEditCommand()
                self.poly_layer.endEditCommand()
                self.point_layer.triggerRepaint()
                self.poly_layer.triggerRepaint()
                self.iface.messageBar().pushMessage("สำเร็จ", "แทรกหมุดเรียบร้อย", level=0, duration=2)
            else:
                self.point_layer.destroyEditCommand()
                self.poly_layer.destroyEditCommand()
        else:
            self.iface.messageBar().pushMessage("แจ้งเตือน", "ไม่พบเส้นขอบที่เชื่อมระหว่างหมุดที่เลือก", level=1, duration=3)

    def reset_tool(self):
        self.selected_points = []
        self.rb_pts.reset()
        self.rb_line.reset()

    def deactivate(self):
        self.snap_indicator.setMatch(QgsPointLocator.Match())
        self.reset_tool()
        super(PointInsertTool, self).deactivate()


# ---------------------------------------------------------------------------
# Tool: วาดรูปแปลงและหมุดใหม่
# ---------------------------------------------------------------------------
class InitialDrawTool(QgsMapToolEmitPoint):
    def __init__(self, iface, point_layer, poly_layer):
        super(InitialDrawTool, self).__init__(iface.mapCanvas())
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.point_layer = point_layer
        self.poly_layer = poly_layer
        self.points = []
        self.is_drawing = False

        self.rb_line = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rb_line.setColor(QColor(255, 165, 0, 150))
        self.rb_line.setWidth(2)

        self.rb_poly = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb_poly.setColor(QColor(0, 0, 255, 40))
        self.rb_poly.setStrokeColor(QColor(0, 0, 255, 200))

    def canvasMoveEvent(self, event):
        curr_pt = event.mapPoint()

        if len(self.points) == 1:
            self.rb_line.reset(QgsWkbTypes.LineGeometry)
            self.rb_line.addPoint(self.points[0])
            self.rb_line.addPoint(curr_pt)

        elif len(self.points) >= 2:
            snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
            final_pt = snap_match.point() if snap_match.isValid() else curr_pt

            self.rb_poly.reset(QgsWkbTypes.PolygonGeometry)
            for p in self.points:
                self.rb_poly.addPoint(p)
            self.rb_poly.addPoint(final_pt)

    def canvasReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
            click_pt = snap_match.point() if snap_match.isValid() else event.mapPoint()

            if not self.is_drawing:
                self.point_layer.beginEditCommand("Create Plot and Points")
                self.poly_layer.beginEditCommand("Create Plot and Points")
                self.is_drawing = True

            if len(self.points) > 2 and snap_match.isValid():
                if snap_match.point().compare(self.points[0], self.canvas.mapUnitsPerPixel() * 10):
                    self.finalize_geometry()
                    return

            self.points.append(click_pt)
            self.create_instant_point(click_pt, len(self.points))

    def create_instant_point(self, pt, count):
        """สร้างหมุด PCM"""
        if not self.point_layer.isEditable():
            self.point_layer.startEditing()

        feat = QgsFeature(self.point_layer.fields())
        feat.setGeometry(QgsGeometry.fromPointXY(pt))
        idx = self.point_layer.fields().indexFromName('pcmname')
        if idx != -1:
            feat.setAttribute(idx, f"PCM_{count}")
        self.point_layer.addFeature(feat)
        self.point_layer.triggerRepaint()

    def finalize_geometry(self):
        """สร้าง Polygon และจบ Command ทั้งหมด"""
        if not self.poly_layer.isEditable():
            self.poly_layer.startEditing()

        poly_feat = QgsFeature(self.poly_layer.fields())
        polygon_pts = [QgsPointXY(p.x(), p.y()) for p in self.points]

        if polygon_pts[0] != polygon_pts[-1]:
            polygon_pts.append(polygon_pts[0])

        poly_feat.setGeometry(QgsGeometry.fromPolygonXY([polygon_pts]))
        self.poly_layer.addFeature(poly_feat)

        self.point_layer.endEditCommand()
        self.poly_layer.endEditCommand()

        self.point_layer.triggerRepaint()
        self.poly_layer.triggerRepaint()
        self.is_drawing = False

        self.iface.messageBar().pushMessage("สำเร็จ", "สร้างรูปแปลงที่ดินเรียบร้อย", level=0)
        self.reset_tool()
        self.canvas.unsetMapTool(self)
        self.iface.actionPan().trigger()

    def reset_tool(self):
        if self.is_drawing:
            self.point_layer.destroyEditCommand()
            self.poly_layer.destroyEditCommand()
            self.is_drawing = False
            self.point_layer.triggerRepaint()
            self.poly_layer.triggerRepaint()

        self.points = []
        self.rb_line.reset()
        self.rb_poly.reset()

    def deactivate(self):
        self.reset_tool()
        super(InitialDrawTool, self).deactivate()
