import requests
import zipfile
import io
import os
from qgis.PyQt.QtCore import Qt, QSettings, QTimer
from qgis.PyQt.QtWidgets import (QAction, QFileDialog, QMessageBox, QDialog, 
                                QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, 
                                QLabel, QListWidget, QAbstractItemView, QInputDialog, QFrame)
from qgis.core import (QgsProject, QgsVectorLayer, QgsRasterLayer, QgsRectangle,
                       QgsGeometry, QgsPointXY, QgsFeatureRequest, QgsPoint, 
                       QgsSymbol, QgsSingleSymbolRenderer, QgsPalLayerSettings, 
                       QgsTextFormat, QgsVectorLayerSimpleLabeling,
                       QgsSnappingConfig, QgsTolerance, QgsPointLocator, QgsWkbTypes, QgsFeature,
                       QgsCoordinateReferenceSystem)
from qgis.gui import (QgsMapToolIdentifyFeature, QgsMapTool,
                      QgsSnapIndicator, 
                      QgsMapCanvas,
                      QgsMapToolEmitPoint,
                      QgsRubberBand)
from qgis.PyQt.QtGui import QColor

class PointEditTool(QgsMapToolIdentifyFeature):
    def __init__(self, iface, layer):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        super(PointEditTool, self).__init__(self.canvas, layer)
        self.layer = layer
        self.snap_indicator = QgsSnapIndicator(self.canvas)
        # ไม่ต้อง setLayer ใน super เพราะเราจะคุมการหา Feature เองให้แม่นยำขึ้น

    def canvasMoveEvent(self, event):
        snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        if snap_match.isValid():
            self.snap_indicator.setMatch(snap_match)
        else:
            self.snap_indicator.setMatch(QgsPointLocator.Match())

    def canvasReleaseEvent(self, event):
        # 1. ดึงจุดพิกัดจากการ Snap
        snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        
        if snap_match.isValid():
            search_point = snap_match.point()
        else:
            search_point = event.mapPoint()

        # 2. ค้นหา Feature ในรัศมี (แก้ไขบรรทัดที่ Error)
        # ใช้ mapUnitsPerPixel() ของ canvas ได้เลย ไม่ต้องผ่าน CRS
        pixel_size = self.canvas.mapUnitsPerPixel() 
        tolerance = pixel_size * 10  # ขยายรัศมีเป็น 10 พิกเซลเพื่อให้จิ้มง่ายขึ้น
        
        rect = QgsRectangle(
            search_point.x() - tolerance, search_point.y() - tolerance,
            search_point.x() + tolerance, search_point.y() + tolerance
        )
        
        # 3. ค้นหาใน Layer
        request = QgsFeatureRequest().setFilterRect(rect).setLimit(1)
        features = list(self.layer.getFeatures(request))

        if features:
            self.edit_point_name(features[0])
        else:
            # ถ้ายังไม่เจอ ลองใช้ Identify มาตรฐานของ QGIS เป็นทางเลือกสุดท้าย
            found = self.identify(event.x(), event.y(), [self.layer], self.IdentifyMode.TopDownAll)
            if found:
                self.edit_point_name(found[0].mFeature)

    def edit_point_name(self, feature):
        old_name = str(feature['pcmname']) if feature['pcmname'] else ""
        new_name, ok = QInputDialog.getText(
            self.iface.mainWindow(), 
            "แก้ไขชื่อหมุด", 
            f"ชื่อเดิม: {old_name}\nใส่ชื่อใหม่:", 
            QLineEdit.Normal, 
            old_name
        )
        
        if ok and new_name:
            idx = self.layer.fields().indexFromName('pcmname')
            if idx != -1:
                if not self.layer.isEditable():
                    self.layer.startEditing()
                
                # --- เพิ่มการใส่ Command เพื่อให้ Undo ได้ ---
                self.layer.beginEditCommand(f"Change Name: {new_name}")
                self.layer.changeAttributeValue(feature.id(), idx, new_name)
                self.layer.endEditCommand()
                # ---------------------------------------
                
                self.layer.triggerRepaint()
                self.iface.messageBar().pushMessage("สำเร็จ", f"เปลี่ยนเป็น {new_name}", level=0, duration=2)
                
class PointDeleteTool(QgsMapTool):
    def __init__(self, canvas, iface, point_layer, poly_layer):
        super().__init__(canvas)
        self.canvas = canvas
        self.iface = iface
        self.point_layer = point_layer
        self.poly_layer = poly_layer
        self.setCursor(Qt.CrossCursor)
        
        # สร้างตัวโชว์จุด Snap สีชมพู
        self.snap_indicator = QgsSnapIndicator(self.canvas)

    def canvasMoveEvent(self, event):
        # หาจุด Snap
        match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        # สั่งให้ Indicator แสดงผล (ถ้าไม่เจอมันจะซ่อนเองอัตโนมัติ)
        self.snap_indicator.setMatch(match)

    def deactivate(self):
        # ล้างจุดสีชมพูออกเมื่อปิดเครื่องมือ
        self.snap_indicator.setMatch(None) 
        super().deactivate()

    def canvasReleaseEvent(self, event):
        match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        
        # เช็คว่า Snap ติดไหม
        if match.isValid():
            search_pt = match.point()
        else:
            search_pt = event.mapPoint()

        # --- ส่วนค้นหาและลบ (โค้ดเดิม) ---
        tol = self.canvas.mapUnitsPerPixel() * 12
        rect = QgsRectangle(search_pt.x() - tol, search_pt.y() - tol,
                            search_pt.x() + tol, search_pt.y() + tol)
        
        req = QgsFeatureRequest().setFilterRect(rect).setLimit(1)
        found_features = list(self.point_layer.getFeatures(req))
        
        if found_features:
            target_f = found_features[0]
            # แสดงหน้าต่างยืนยันการลบ...
            res = QMessageBox.question(self.iface.mainWindow(), "ยืนยันการลบ", 
                                        f"ลบหมุด {target_f['pcmname']}?", 
                                        QMessageBox.Yes | QMessageBox.No)
            if res == QMessageBox.Yes:
                self.execute_delete(target_f, target_f.geometry().asPoint())

    def execute_delete(self, point_feat, point_geom):
        # ใช้ Edit Command เพื่อให้ Undo ได้ในครั้งเดียว
        self.point_layer.beginEditCommand(f"Delete Point {point_feat.id()}")
        self.poly_layer.beginEditCommand(f"Remove Node for Point {point_feat.id()}")
        
        try:
            # ลบหมุดแดง
            self.point_layer.deleteFeature(point_feat.id())
            
            # ค้นหาและลบ Node ใน Polygon
            tol = self.canvas.mapUnitsPerPixel() * 5
            for poly_feat in self.poly_layer.getFeatures():
                geom = poly_feat.geometry()
                # เช็คว่า Polygon นี้มีจุดที่พิกัดตรงกับหมุดแดงที่จะลบไหม
                for i, v in enumerate(geom.vertices()):
                    if QgsPointXY(v).compare(point_geom, tol):
                        # ลบ Node ตำแหน่งที่ i ออก
                        self.poly_layer.deleteVertex(poly_feat.id(), i)
                        break 
            
            self.point_layer.endEditCommand()
            self.poly_layer.endEditCommand()
            
            self.point_layer.triggerRepaint()
            self.poly_layer.triggerRepaint()
            self.iface.messageBar().pushMessage("สำเร็จ", "ลบข้อมูลเรียบร้อยแล้ว", level=0, duration=2)
            
        except Exception as e:
            self.point_layer.destroyEditCommand()
            self.poly_layer.destroyEditCommand()
            self.iface.messageBar().pushMessage("ผิดพลาด", f"ไม่สามารถลบได้: {str(e)}", level=2, duration=2)
        
class FileSelectDialog(QDialog):
    def __init__(self, file_list, title, label_text, parent=None):
        super(FileSelectDialog, self).__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(550)
        layout = QVBoxLayout(self)
        self.list_widget = QListWidget()
        for path in file_list:
            self.list_widget.addItem(path)
        self.list_widget.setSelectionMode(QAbstractItemView.SingleSelection)
        layout.addWidget(QLabel(f"<b>{label_text}</b>"))
        layout.addWidget(self.list_widget)
        btn_ok = QPushButton("ตกลง")
        btn_ok.clicked.connect(self.accept)
        layout.addWidget(btn_ok)

    def get_selected_file(self):
        selected = self.list_widget.selectedItems()
        return selected[0].text() if selected else None

class GPKGEditorDialog(QDialog):
    def __init__(self, parent=None):
        super(GPKGEditorDialog, self).__init__(parent)
        self.setWindowTitle("GPKG Editor")
        self.setMinimumWidth(450)
        layout = QVBoxLayout(self)

        # --- โซนที่ 1: การสแกนและโหลดข้อมูล ---
        layout.addWidget(QLabel("<b>📁 โซนสแกนและโหลดข้อมูล</b>"))
        path_layout = QHBoxLayout()
        self.line_path = QLineEdit()
        self.btn_browse = QPushButton("เลือก Folder...")
        self.btn_browse.clicked.connect(self.browse_folder)
        path_layout.addWidget(self.line_path)
        path_layout.addWidget(self.btn_browse)
        layout.addLayout(path_layout)
        
        self.btn_load = QPushButton("🚀 สแกนและโหลดข้อมูล")
        self.btn_load.setStyleSheet("font-weight: bold; height: 35px; background-color: #e1f5fe;")
        layout.addWidget(self.btn_load)

        # เส้นแบ่งโซน
        line1 = QFrame()
        line1.setFrameShape(QFrame.HLine)
        line1.setFrameShadow(QFrame.Sunken)
        layout.addWidget(line1)
        layout.addSpacing(5)

        # --- โซนที่ 2: เครื่องมือจัดการหมุด (จัดกลุ่มซ้าย-ขวา) ---
        layout.addWidget(QLabel("<b>🛠️ เครื่องมือจัดการหมุด</b>"))
        
        # บรรทัด: ย้ายหมุด (ซ้าย) | แทรกหมุด (ขวา)
        row1_layout = QHBoxLayout()
        self.btn_move_point = QPushButton("📍 ย้ายหมุด")
        self.btn_move_point.setStyleSheet("font-weight: bold; height: 35px; ")
        self.btn_move_point.setEnabled(False)
        
        self.btn_insert_point = QPushButton("➕ แทรกหมุด")
        self.btn_insert_point.setStyleSheet("font-weight: bold; height: 35px; ")
        self.btn_insert_point.setEnabled(False)
        
        row1_layout.addWidget(self.btn_move_point)
        row1_layout.addWidget(self.btn_insert_point)
        layout.addLayout(row1_layout)

        # บรรทัด: แก้ไขชื่อหมุด (ซ้าย) | ลบหมุด (ขวา)
        row2_layout = QHBoxLayout()
        self.btn_edit_point = QPushButton("✏️ แก้ไขชื่อหมุด")
        self.btn_edit_point.setStyleSheet("font-weight: bold; height: 35px;")
        self.btn_edit_point.setEnabled(False)
        
        self.btn_delete_point = QPushButton("🗑️ ลบหมุด")
        self.btn_delete_point.setStyleSheet("font-weight: bold; height: 35px; ")
        self.btn_delete_point.setEnabled(False) # ตั้งเริ่มต้นให้กดไม่ได้จนกว่าจะโหลดข้อมูล
        
        row2_layout.addWidget(self.btn_edit_point)
        row2_layout.addWidget(self.btn_delete_point)
        layout.addLayout(row2_layout)

        # เส้นแบ่งโซน
        layout.addSpacing(5)
        line2 = QFrame()
        line2.setFrameShape(QFrame.HLine)
        line2.setFrameShadow(QFrame.Sunken)
        layout.addWidget(line2)
        layout.addSpacing(5)

        # --- โซนที่ 3: ระบบควบคุมและย้อนกลับ ---
        # บรรทัด: Reset / Cancel (ซ้าย) | Undo (ขวา)
        row3_layout = QHBoxLayout()
        self.btn_reset = QPushButton("🔄 Reset / Cancel")
        self.btn_reset.setStyleSheet("font-weight: bold; height: 30px; background-color: #f5f5f5;")
        
        self.btn_undo = QPushButton("↩️ Undo (ย้อนกลับ)")
        self.btn_undo.setStyleSheet("font-weight: bold; height: 30px; background-color: #ffebee; color: #c62828;")
        
        row3_layout.addWidget(self.btn_reset)
        row3_layout.addWidget(self.btn_undo)
        layout.addLayout(row3_layout)
        
        self.btn_save = QPushButton("💾 บันทึกการแก้ไขทั้งหมด (Save)")
        self.btn_save.setStyleSheet("height: 45px; font-weight: bold; background-color: #c8e6c9; color: #2e7d32; font-size: 14px;")
        self.btn_save.setEnabled(False)
        layout.addWidget(self.btn_save)
        
        
        layout.addSpacing(5)
        line3 = QFrame()
        line3.setFrameShape(QFrame.HLine)
        line3.setFrameShadow(QFrame.Sunken)
        layout.addWidget(line3)
        layout.addSpacing(5)

        self.btn_upd = QPushButton("🚀 Check Update")
        self.btn_upd.setStyleSheet("height: 30px; background-color: #f3e5f5;")
        layout.addWidget(self.btn_upd)

        lbl_author = QLabel("จัดทำโดย: ชาคฤตย์ จันทรสุกศรี")
        lbl_dept = QLabel("กองเทคโนโลยีทำแผนที่ กรมที่ดิน")
        
        # ปรับ Font ให้เล็กลงและวางกึ่งกลาง
        info_font = lbl_author.font()
        info_font.setPointSize(9)
        lbl_author.setFont(info_font)
        lbl_dept.setFont(info_font)
        lbl_author.setAlignment(Qt.AlignCenter)
        lbl_dept.setAlignment(Qt.AlignCenter)
        
        layout.addWidget(lbl_author)
        layout.addWidget(lbl_dept)
        
    def browse_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "เลือกโฟลเดอร์")
        if folder:
            self.line_path.setText(folder)
            
class PointMoveTool(QgsMapToolEmitPoint):
    def __init__(self, iface, point_layer, poly_layer):
        super(PointMoveTool, self).__init__(iface.mapCanvas())
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.point_layer = point_layer
        self.poly_layer = poly_layer
        self.is_dragging = False
        self.target_feat_id = None
        self.poly_nodes = []
        
        # เพิ่มตัวช่วยแสดงผล Snap
        self.snap_indicator = QgsSnapIndicator(self.canvas)
        
        self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rubber_band.setColor(QColor(0, 255, 0, 100))
        self.rubber_band.setWidth(2)

    def canvasMoveEvent(self, event):
        # ทำให้ Snap ขึ้นตอนใช้เครื่องมือย้าย
        snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        if snap_match.isValid():
            self.snap_indicator.setMatch(snap_match)
        else:
            self.snap_indicator.setMatch(QgsPointLocator.Match())

        # ส่วนของ Preview (ถ้ากำลังลากอยู่)
        if self.is_dragging:
            curr_pt = event.mapPoint()
            self.rubber_band.reset(QgsWkbTypes.PolygonGeometry)
            if self.poly_nodes:
                node_info = self.poly_nodes[0]
                feat = self.poly_layer.getFeature(node_info['fid'])
                tmp_geom = QgsGeometry(feat.geometry())
                # ย้ายจุดใน Preview
                tmp_geom.moveVertex(curr_pt.x(), curr_pt.y(), node_info['node_idx'])
                self.rubber_band.setToGeometry(tmp_geom, self.poly_layer)

    def canvasPressEvent(self, event):
        # --- 1. ล้างค่าเดิมทุกครั้งที่เริ่มคลิกใหม่ (ป้องกันปัญหาจำค่าค้าง) ---
        self.is_dragging = False
        self.target_feat_id = None
        self.poly_nodes = []

        snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        search_point = snap_match.point() if snap_match.isValid() else event.mapPoint()

        # --- 2. ค้นหาหมุด Point ---
        tolerance = self.canvas.mapUnitsPerPixel() * 10 
        rect = QgsRectangle(search_point.x() - tolerance, search_point.y() - tolerance,
                            search_point.x() + tolerance, search_point.y() + tolerance)
        
        request = QgsFeatureRequest().setFilterRect(rect).setLimit(1)
        point_features = list(self.point_layer.getFeatures(request))

        if point_features:
            self.is_dragging = True
            target_feat = point_features[0]
            self.target_feat_id = target_feat.id()
            start_point = target_feat.geometry().asPoint()
            
            # --- 3. ค้นหา Node ใน Polygon (Topological) ---
            # สำคัญ: ต้องค้นหาใหม่ทุกครั้งที่กด เพื่อให้ได้ตำแหน่ง Node ล่าสุด
            poly_tolerance = self.canvas.mapUnitsPerPixel() * 5
            for feat in self.poly_layer.getFeatures():
                geom = feat.geometry()
                for i, pt in enumerate(geom.vertices()):
                    if QgsPointXY(pt).compare(QgsPointXY(start_point), poly_tolerance):
                        # เก็บค่า Node ล่าสุดไว้
                        self.poly_nodes.append({'fid': feat.id(), 'node_idx': i})
        else:
            self.iface.messageBar().pushMessage("แจ้งเตือน", "ไม่พบหมุดแดงในรัศมีที่คลิก", level=1, duration=2)

    def canvasReleaseEvent(self, event):
        if not self.is_dragging or self.target_feat_id is None:
            return

        end_pt = event.mapPoint()
        
        # --- 4. จัดการ Undo ด้วย Edit Command ---
        # ต้องเปิดโหมดแก้ไขทั้งคู่
        if not self.point_layer.isEditable(): self.point_layer.startEditing()
        if not self.poly_layer.isEditable(): self.poly_layer.startEditing()

        # สร้าง Command Name เดียวกันเพื่อให้จำง่าย
        cmd_name = f"Move Point {self.target_feat_id}"
        
        # เริ่มต้นบันทึก Step สำหรับ Undo
        self.point_layer.beginEditCommand(cmd_name)
        self.poly_layer.beginEditCommand(cmd_name)

        success = False
        try:
            # ย้าย Point
            self.point_layer.moveVertex(end_pt.x(), end_pt.y(), self.target_feat_id, 0)
            
            # ย้าย Node ทั้งหมดใน Polygon ที่เราหาเจอ
            for node in self.poly_nodes:
                self.poly_layer.moveVertex(end_pt.x(), end_pt.y(), node['fid'], node['node_idx'])
            
            success = True
        except Exception as e:
            print(f"Error during move: {e}")

        # ปิด Command
        self.point_layer.endEditCommand()
        self.poly_layer.endEditCommand()

        if success:
            self.point_layer.triggerRepaint()
            self.poly_layer.triggerRepaint()
            self.iface.messageBar().pushMessage("สำเร็จ", "ย้ายหมุดเรียบร้อย", level=0, duration=2)

        self.rubber_band.reset()
        self.is_dragging = False

    def deactivate(self):
        self.snap_indicator.setMatch(QgsPointLocator.Match())
        self.rubber_band.reset()
        super(PointMoveTool, self).deactivate()
        
class PointInsertTool(QgsMapToolEmitPoint):
    def __init__(self, iface, point_layer, poly_layer):
        super(PointInsertTool, self).__init__(iface.mapCanvas())
        self.iface, self.canvas = iface, iface.mapCanvas()
        self.point_layer, self.poly_layer = point_layer, poly_layer
        self.snap_indicator = QgsSnapIndicator(self.canvas)
        self.selected_points = []
        self.rb_pts = QgsRubberBand(self.canvas, QgsWkbTypes.PointGeometry)
        self.rb_pts.setColor(QColor(255, 255, 0, 200))
        self.rb_line = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rb_line.setColor(QColor(255, 165, 0, 200)) # สีส้ม Preview
        self.rb_line.setWidth(2)

    def canvasMoveEvent(self, event):
        snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        self.snap_indicator.setMatch(snap_match if snap_match.isValid() else QgsPointLocator.Match())
        
        if len(self.selected_points) == 2:
            self.rb_line.reset(QgsWkbTypes.LineGeometry)
            self.rb_line.addPoint(self.selected_points[0]['point'])
            self.rb_line.addPoint(event.mapPoint())
            self.rb_line.addPoint(self.selected_points[1]['point'])

    def canvasReleaseEvent(self, event):
        # จังหวะที่ 1 & 2: เลือกหมุดอ้างอิง
        if len(self.selected_points) < 2:
            snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
            search_pt = snap_match.point() if snap_match.isValid() else event.mapPoint()
            
            # --- วิธีใหม่: ค้นหา Feature จากเลเยอร์โดยตรงในรัศมีรอบจุดที่คลิก ---
            tol = self.canvas.mapUnitsPerPixel() * 10
            rect = QgsRectangle(search_pt.x() - tol, search_pt.y() - tol,
                                search_pt.x() + tol, search_pt.y() + tol)
            
            # ค้นหาหมุดแดงในระยะที่คลิก
            req = QgsFeatureRequest().setFilterRect(rect).setLimit(1)
            found_features = list(self.point_layer.getFeatures(req))
            
            if found_features:
                # ถ้าเจอหมุดแดง ให้ดึงพิกัดจริงๆ ของหมุดนั้นมาใช้ (ไม่ใช่พิกัดที่เมาส์จิ้ม)
                actual_pt = found_features[0].geometry().asPoint()
                self.selected_points.append({'point': actual_pt})
                self.rb_pts.addPoint(actual_pt)
                
                msg = "เลือกหมุดที่ 2" if len(self.selected_points) == 1 else "คลิกจุดเพื่อวางหมุดใหม่ (มีเส้นส้มตาม)"
                self.iface.messageBar().pushMessage("ระบบ", msg, level=0, duration=2)
            else:
                self.iface.messageBar().pushMessage("แจ้งเตือน", "กรุณาคลิกให้โดนหมุดแดง (ให้ขึ้น Snap สีชมพู)", level=1)
            return
        
        # จังหวะที่ 3: เลือกพิกัดที่จะวางจริง (ไม่ต้องเช็คเลเยอร์ คลิกตรงไหนก็ได้)
        snap_match = self.canvas.snappingUtils().snapToMap(event.mapPoint())
        new_pt = snap_match.point() if snap_match.isValid() else event.mapPoint()
        
        self.execute_insert(new_pt)
        self.reset_tool()

    def execute_insert(self, new_pt):
        if len(self.selected_points) < 2:
            return

        p1 = self.selected_points[0]['point']
        p2 = self.selected_points[1]['point']
        
        target_poly = None
        insert_idx = -1
        tol = self.canvas.mapUnitsPerPixel() * 15 
        
        # 1. ค้นหา Polygon
        for feat in self.poly_layer.getFeatures():
            vertices = [QgsPointXY(v) for v in feat.geometry().vertices()]
            idx1, idx2 = -1, -1
            for i, v in enumerate(vertices):
                if v.compare(p1, tol): idx1 = i
                if v.compare(p2, tol): idx2 = i
            
            if idx1 != -1 and idx2 != -1:
                diff = abs(idx1 - idx2)
                num_v = len(vertices)
                if diff == 1 or diff == (num_v - 1):
                    target_poly = feat
                    insert_idx = max(idx1, idx2) if diff == 1 else 0
                    break

        if target_poly:
            # --- เริ่มขั้นตอนการแก้ไข (รวบทุกอย่างเป็น Command เดียว) ---
            self.point_layer.beginEditCommand("Insert Point and Name")
            self.poly_layer.beginEditCommand("Insert Point and Name")
            
            # สร้าง Feature หมุดใหม่
            new_f = QgsFeature(self.point_layer.fields())
            new_f.setGeometry(QgsGeometry.fromPointXY(new_pt))
            
            # ตั้งชื่อเริ่มต้นไว้ก่อน
            name_idx = self.point_layer.fields().indexFromName('pcmname')
            if name_idx != -1:
                new_f.setAttribute(name_idx, "NEW_PCM")
            
            # เพิ่มหมุด และ แทรก Node
            success_pt = self.point_layer.addFeature(new_f)
            new_fid = new_f.id()
            success_poly = self.poly_layer.insertVertex(new_pt.x(), new_pt.y(), target_poly.id(), insert_idx)
            
            if success_pt and success_poly:
                # รีเฟรชหน้าจอชั่วคราวเพื่อให้เห็นหมุดก่อนพิมพ์ชื่อ
                self.point_layer.triggerRepaint()
                self.poly_layer.triggerRepaint()

                # --- 2. เด้ง Popup ถามชื่อหมุด ---
                new_name, ok = QInputDialog.getText(
                    self.iface.mainWindow(), 
                    "ตั้งชื่อหมุดใหม่", 
                    "กรุณาใส่ชื่อหมุดที่แทรกใหม่:", 
                    QLineEdit.Normal, 
                    "NEW_PCM"
                )
                
                if ok and new_name:
                    # แก้ไขชื่อใน Feature เดิมที่เพิ่งสร้าง
                    if name_idx != -1:
                        self.point_layer.changeAttributeValue(new_fid, name_idx, new_name)
                
                # --- สั่งปิด Command พร้อมกันตรงนี้ ---
                # การกด Undo 1 ครั้งจะย้อนกลับมาที่จุดนี้ (คือหายไปทั้งหมุด เส้น และชื่อ)
                self.point_layer.endEditCommand()
                self.poly_layer.endEditCommand()
                
                self.point_layer.triggerRepaint()
                self.poly_layer.triggerRepaint()
                self.iface.messageBar().pushMessage("สำเร็จ", "เพิ่มหมุดเรียบร้อย", level=0, duration=2)
            else:
                self.point_layer.destroyEditCommand()
                self.poly_layer.destroyEditCommand()
                self.iface.messageBar().pushMessage("ผิดพลาด", "ไม่สามารถบันทึกข้อมูลได้", level=2, duration=2)
        else:
            self.iface.messageBar().pushMessage("แจ้งเตือน", "ไม่พบเส้นขอบที่เชื่อมหมุดสองตัวนี้", level=1, duration=2)

    def reset_tool(self):
        self.selected_points = []; self.rb_pts.reset(); self.rb_line.reset()

    def deactivate(self): self.reset_tool(); super(PointInsertTool, self).deactivate()
        
class GPKGEditor:
    def __init__(self, iface):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        self.dlg = GPKGEditorDialog(self.iface.mainWindow())
        self.loaded_layer_ids = []
        self.point_layer = None
        self.edit_tool = None
        self.version = "1.0.0"
        
    def initGui(self):
        self.action = QAction("เปิด GPKG Editor", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&GPKG Editor", self.action)
        self.dlg.btn_upd.clicked.connect(self.update_plugin)
        self.dlg.btn_load.clicked.connect(self.process_load)
        self.dlg.btn_edit_point.clicked.connect(self.activate_edit_tool)
        self.dlg.btn_move_point.clicked.connect(self.activate_move_tool)
        self.dlg.btn_reset.clicked.connect(self.reset_to_select)
        self.dlg.btn_undo.clicked.connect(self.undo_action)
        self.dlg.btn_save.clicked.connect(self.save_changes)
        self.dlg.btn_insert_point.clicked.connect(self.activate_insert_tool)
        self.dlg.btn_delete_point.clicked.connect(self.activate_delete_tool)
        
    def update_plugin(self):
        V_URL = "https://raw.githubusercontent.com/chakrit39/Multi_Layer_Edit_Pro/refs/heads/main/version.txt"
        Z_URL = "https://github.com/chakrit39/Multi_Layer_Edit_Pro/raw/refs/heads/main/Multi_Layer_Edit_Pro.zip"
        
        try:
            # 1. ตรวจสอบเวอร์ชัน
            res = requests.get(V_URL, timeout=5)
            remote_version = res.text.strip()
            
            if remote_version > self.version:
                reply = QMessageBox.question(
                    self.dlg, "พบเวอร์ชันใหม่", 
                    f"เวอร์ชันใหม่ ({remote_version}) พร้อมใช้งาน\nคุณต้องการอัปเดตทันทีหรือไม่?",
                    QMessageBox.Yes | QMessageBox.No
                )
                
                if reply == QMessageBox.Yes:
                    # 2. ดาวน์โหลดและแตกไฟล์
                    r = requests.get(Z_URL)
                    z = zipfile.ZipFile(io.BytesIO(r.content))
                    
                    # หาพาธที่ติดตั้งปลั๊กอิน (โฟลเดอร์แม่ของโฟลเดอร์ปัจจุบัน)
                    plugin_dir = os.path.dirname(os.path.dirname(__file__))
                    z.extractall(plugin_dir)
                    
                    QMessageBox.information(self.dlg, "อัปเดตสำเร็จ", "อัปเดตปลั๊กอินเรียบร้อยแล้ว!\nกรุณา Restart QGIS เพื่อเริ่มใช้งานเวอร์ชันใหม่")
            else:
                QMessageBox.information(self.dlg, "อัปเดต", "คุณกำลังใช้งานเวอร์ชันล่าสุดแล้ว")
                
        except Exception as e:
            QMessageBox.warning(self.dlg, "เกิดข้อผิดพลาด", f"ไม่สามารถตรวจสอบการอัปเดตได้:\n{str(e)}")
        
    def activate_delete_tool(self):
        if not self.point_layer or not self.poly_layer:
            return
        # สร้าง Tool และส่ง Layer เข้าไป
        self.delete_tool = PointDeleteTool(self.canvas, self.iface, self.point_layer, self.poly_layer)
        self.canvas.setMapTool(self.delete_tool)
        
    def activate_insert_tool(self):
        if self.point_layer and self.poly_layer:
            self.insert_tool = PointInsertTool(self.iface, self.point_layer, self.poly_layer)
            self.canvas.setMapTool(self.insert_tool)
           
            
    def save_changes(self):
        """ บันทึกการแก้ไขลงไฟล์ GPKG และหยุดโหมดการแก้ไข """
        layers_to_save = [self.point_layer, self.poly_layer]
        success_count = 0
        
        for layer in layers_to_save:
            if layer and layer.isEditable():
                if layer.commitChanges(): # บันทึกและปิดโหมดแก้ไข
                    success_count += 1
                else:
                    # ถ้าบันทึกไม่สำเร็จ (เช่น ไฟล์ถูก Lock)
                    self.iface.messageBar().pushMessage("Error", f"ไม่สามารถบันทึกเลเยอร์ {layer.name()} ได้: {layer.commitErrors()}", level=2)
                    layer.rollBack() # ย้อนกลับข้อมูลเพื่อความปลอดภัย
        
        if success_count > 0:
            self.iface.messageBar().pushMessage("สำเร็จ", "บันทึกข้อมูลลง Geopackage เรียบร้อยแล้ว", level=0, duration=3)
            # หลังจากเซฟแล้ว ให้เปิดโหมดแก้ไขต่อเพื่อทำงานต่อได้ทันที (ถ้าต้องการ)
            self.point_layer.startEditing()
            self.poly_layer.startEditing()
            
    def undo_action(self):
        """ ย้อนกลับการกระทำล่าสุดในเลเยอร์ที่กำลังแก้ไข """
        if self.point_layer and self.point_layer.isEditable():
            self.point_layer.undoStack().undo()
            self.point_layer.triggerRepaint()
            
        if self.poly_layer and self.poly_layer.isEditable():
            self.poly_layer.undoStack().undo()
            self.poly_layer.triggerRepaint()
            
        self.iface.messageBar().pushMessage("Undo", "ย้อนกลับการแก้ไขล่าสุดแล้ว", level=0, duration=2)
        
    def reset_to_select(self):
        """ คืนค่าเครื่องมือกลับไปเป็นลูกศรเลือก (Select) มาตรฐานของ QGIS """
        self.canvas.unsetMapTool(self.edit_tool)
        if hasattr(self, 'move_tool'):
            self.canvas.unsetMapTool(self.move_tool)
        
        # ตั้งค่ากลับเป็นเครื่องมือ Pan หรือสัญลักษณ์ลูกศร
        self.iface.actionPan().trigger() 
        self.iface.messageBar().pushMessage("ระบบ", "คืนค่าเป็นเครื่องมือปกติแล้ว", level=0, duration=2)
        
    def activate_move_tool(self):
        if self.point_layer and self.poly_layer:
            # สร้างเลเยอร์ Polygon ชั่วคราวมาอ้างอิง
            self.move_tool = PointMoveTool(self.iface, self.point_layer, self.poly_layer)
            self.canvas.setMapTool(self.move_tool)
            self.iface.messageBar().pushMessage("ระบบ", "คลิกค้างที่จุดแล้วลากเพื่อย้ายตำแหน่ง", level=0, duration=3)
            
    def unload(self):
        self.iface.removePluginMenu("&GPKG Editor", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        self.dlg.show()

    def clear_previous_layers(self):
        if self.loaded_layer_ids:
            QgsProject.instance().removeMapLayers(self.loaded_layer_ids)
            self.loaded_layer_ids = []
            self.point_layer = None

    def setup_snapping(self, layers):
        config = QgsProject.instance().snappingConfig()
        config.setEnabled(True)
        config.setMode(QgsSnappingConfig.AdvancedConfiguration)
        
        config.clearIndividualLayerSettings()
        
        for lyr in layers:
            if lyr:
                setting = QgsSnappingConfig.IndividualLayerSettings()
                setting.setEnabled(True)
                
                # --- ใช้การกำหนดค่าผ่าน Property โดยตรง (Modern Pythonic Way) ---
                # วิธีนี้จะไม่มี Warning และรันผ่านแน่นอนใน QGIS 3.x ล่าสุด
                setting.type = QgsSnappingConfig.Vertex | QgsSnappingConfig.Segment
                
                # ตั้งค่าระยะ Tolerance
                setting.setTolerance(20)
                setting.setUnits(QgsTolerance.Pixels)
                
                config.setIndividualLayerSettings(lyr, setting)
        
        QgsProject.instance().setSnappingConfig(config)

    def activate_edit_tool(self):
        if self.point_layer:
            # แก้ไขการส่งค่า self.iface เข้าไป
            self.edit_tool = PointEditTool(self.iface, self.point_layer)
            self.canvas.setMapTool(self.edit_tool)
            self.iface.messageBar().pushMessage("ระบบ", "เครื่องมือเปิดแล้ว: เลื่อนเมาส์ให้ขึ้นสี่เหลี่ยมแล้วคลิก", level=0)

    def process_load(self):
        # --- ส่วนการโหลดไฟล์คงเดิม แต่เพิ่มการเช็ค commit ---
        root_path = self.dlg.line_path.text().strip()
        if not root_path or not os.path.exists(root_path):
            QMessageBox.critical(self.dlg, "ระงับการทำงาน", "กรุณาเลือกโฟลเดอร์หลักก่อน")
            return

        all_gpkgs = [os.path.join(r, f) for r, d, files in os.walk(root_path) for f in files if f.endswith('.gpkg')]
        all_images = [os.path.join(root_path, f) for f in os.listdir(root_path) if f.lower().endswith('.jpg')]

        if not all_gpkgs or not all_images:
            QMessageBox.critical(self.dlg, "ไม่พบไฟล์", "ต้องมีทั้งไฟล์ .gpkg และรูปภาพ")
            return
        
        # เลือกไฟล์ (Logic เดิม)
        selected_gpkg = all_gpkgs[0] if len(all_gpkgs) == 1 else None
        if len(all_gpkgs) > 1:
            gpkg_dlg = FileSelectDialog(all_gpkgs, "เลือกไฟล์ GPKG", "พบไฟล์ GPKG หลายไฟล์:", self.dlg)
            if gpkg_dlg.exec_(): selected_gpkg = gpkg_dlg.get_selected_file()
        if not selected_gpkg: return

        selected_img = all_images[0] if len(all_images) == 1 else None
        if len(all_images) > 1:
            img_dlg = FileSelectDialog(all_images, "เลือกรูปภาพ", "พบรูปภาพหลายไฟล์:", self.dlg)
            if img_dlg.exec_(): selected_img = img_dlg.get_selected_file()
        if not selected_img: return

        self.clear_previous_layers()
        project = QgsProject.instance()
        root_node = project.layerTreeRoot()
        invalid_crs = QgsCoordinateReferenceSystem() 
        QgsProject.instance().setCrs(invalid_crs)
        
        if self.loaded_layer_ids:
            QgsProject.instance().removeMapLayers(self.loaded_layer_ids)
            self.loaded_layer_ids = []
            
        # โหลด Raster
        rlayer = QgsRasterLayer(selected_img, f"[IMG] {os.path.basename(selected_img)}")
        if rlayer.isValid():
            project.addMapLayer(rlayer, False)
            root_node.insertLayer(-1, rlayer) # วางไว้ล่างสุด
            self.loaded_layer_ids.append(rlayer.id())

        # โหลด Polygon
        self.poly_layer = QgsVectorLayer(f"{selected_gpkg}|layername=parcel_polygon", "parcel_polygon", "ogr")
        if self.poly_layer.isValid():
            self.poly_layer.setCrs(invalid_crs)
            symbol = QgsSymbol.defaultSymbol(self.poly_layer.geometryType())
            symbol.setColor(QColor(0, 0, 255))
            symbol_layer = symbol.symbolLayer(0)
            symbol_layer.setBrushStyle(Qt.NoBrush)
            symbol_layer.setStrokeColor(QColor(0, 0, 255))
            symbol_layer.setStrokeWidth(1)
            self.poly_layer.setRenderer(QgsSingleSymbolRenderer(symbol))
            
            project.addMapLayer(self.poly_layer, False)
            root_node.insertLayer(0, self.poly_layer)
            self.loaded_layer_ids.append(self.poly_layer.id())
            self.poly_layer.startEditing() # เปิดโหมดแก้ไขไว้เลย

        # โหลด Point
        self.point_layer = QgsVectorLayer(f"{selected_gpkg}|layername=parcel_pcm", "parcel_pcm", "ogr")
        if self.point_layer.isValid():
            self.point_layer.setCrs(invalid_crs)
            p_symbol = QgsSymbol.defaultSymbol(self.point_layer.geometryType())
            p_symbol.setColor(QColor(255, 0, 0))
            p_symbol.setSize(3.0)
            self.point_layer.setRenderer(QgsSingleSymbolRenderer(p_symbol))

            # ตั้งค่า Label
            label_settings = QgsPalLayerSettings()
            label_settings.fieldName = "pcmname"
            label_settings.enabled = True
            text_format = QgsTextFormat()
            text_format.setSize(12)
            text_format.setColor(QColor(255, 0, 0))
            text_format.buffer().setEnabled(True)
            text_format.buffer().setSize(1)
            label_settings.setFormat(text_format)
            self.point_layer.setLabeling(QgsVectorLayerSimpleLabeling(label_settings))
            self.point_layer.setLabelsEnabled(True)

            project.addMapLayer(self.point_layer, False)
            root_node.insertLayer(0, self.point_layer)
            self.loaded_layer_ids.append(self.point_layer.id())
            self.point_layer.startEditing()
            
        if self.poly_layer.isValid():
            QgsProject.instance().setCrs(self.poly_layer.crs())
            
        # ตั้งค่า Snap และเปิดปุ่ม
        if self.point_layer and self.poly_layer:
            self.setup_snapping([self.point_layer, self.poly_layer])
            self.dlg.btn_edit_point.setEnabled(True)
            self.dlg.btn_move_point.setEnabled(True)
            self.dlg.btn_save.setEnabled(True)
            self.dlg.btn_insert_point.setEnabled(True)
            self.dlg.btn_delete_point.setEnabled(True)
            self.iface.setActiveLayer(self.point_layer)
            self.iface.zoomToActiveLayer() # ใช้ผ่าน iface แทน canvas